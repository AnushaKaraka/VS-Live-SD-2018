﻿namespace CosmosDbDemos.DataLayer
{
    public class DocumentCollectionInfo
    {
        public string Id { get; set; }
        public string ResourceId { get; set; }
        public string SelfLink { get; set; } 
        public string PartitionKey { get; set; }
        public int Throughput { get; set; }

    }
}
