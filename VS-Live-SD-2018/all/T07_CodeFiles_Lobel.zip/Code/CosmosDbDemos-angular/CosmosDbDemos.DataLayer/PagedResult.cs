﻿using System.Collections.Generic;

namespace CosmosDbDemos.DataLayer
{
    public class PagedResult
    {
        public IEnumerable<object> Data { get; set; }
        public string ContinuationToken { get; set; }
    }
}
