﻿using CosmosDbDemos.Shared;
using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CosmosDbDemos.DataLayer
{
    public static class SqlApiCollectionsRepo
    {
        public static IEnumerable<DocumentCollectionInfo> GetCollections(AppConfig config, string databaseId)
        {
            System.Diagnostics.Debugger.Break();

            var result = new List<DocumentCollectionInfo>();
            var databaseUri = UriFactory.CreateDatabaseUri(databaseId);
            using (var client = new DocumentClient(new Uri(config.CosmosDbEndpoint), config.CosmosDbMasterKey))
            {
                var collections = client
                    .CreateDocumentCollectionQuery(databaseUri)
                    .ToList()
                    .OrderBy(c => c.Id);    // not directly supported on query; must follow .ToList

                var offers = client
                    .CreateOfferQuery()
                    .ToList()
                    .Where(o => collections.Any(c => c.SelfLink == o.ResourceLink));

                foreach (var collection in collections)
                {
                    var offer = offers.Single(o => o.ResourceLink == collection.SelfLink);
                    dynamic offerJson = JsonConvert.DeserializeObject(offer.ToString());
                    var throughput = (int)offerJson.content.offerThroughput.Value;

                    var dci = new DocumentCollectionInfo
                    {
                        Id = collection.Id,
                        ResourceId = collection.ResourceId,
                        SelfLink = collection.SelfLink,
                        PartitionKey = collection.PartitionKey.Paths[0],
                        Throughput = throughput
                    };

                    result.Add(dci);
                }

                return result;
            }
        }

        public static async Task<DocumentCollection> CreateCollection(AppConfig config, string databaseId, string collectionId, string partitionKey, int throughput)
        {
            System.Diagnostics.Debugger.Break();

            var databaseUri = UriFactory.CreateDatabaseUri(databaseId);
            using (var client = new DocumentClient(new Uri(config.CosmosDbEndpoint), config.CosmosDbMasterKey))
            {
                var partitionKeyDefinition = new PartitionKeyDefinition();
                partitionKeyDefinition.Paths.Add(partitionKey);

                var collectionDefinition = new DocumentCollection
                {
                    Id = collectionId,
                    PartitionKey = partitionKeyDefinition
                };
                var options = new RequestOptions { OfferThroughput = throughput };

                var result = await client.CreateDocumentCollectionAsync(databaseUri, collectionDefinition, options);
                var collection = result.Resource;

                return collection;
            }
        }

        public static async Task DeleteCollection(AppConfig config, string databaseId, string collectionId)
        {
            System.Diagnostics.Debugger.Break();

            var collectionUri = UriFactory.CreateDocumentCollectionUri(databaseId, collectionId);
            using (var client = new DocumentClient(new Uri(config.CosmosDbEndpoint), config.CosmosDbMasterKey))
            {
                await client.DeleteDocumentCollectionAsync(collectionUri);
            }
        }

    }

}
