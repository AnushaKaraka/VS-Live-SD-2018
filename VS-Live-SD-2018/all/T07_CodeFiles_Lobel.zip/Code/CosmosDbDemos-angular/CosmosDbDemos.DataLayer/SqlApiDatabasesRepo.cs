﻿using CosmosDbDemos.Shared;
using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CosmosDbDemos.DataLayer
{
    public static class SqlApiDatabasesRepo
    {
        public static IEnumerable<Database> GetDatabases(AppConfig config)
        {
            System.Diagnostics.Debugger.Break();

            using (var client = new DocumentClient(new Uri(config.CosmosDbEndpoint), config.CosmosDbMasterKey))
            {
                var databases = client
                    .CreateDatabaseQuery()
                    .ToList()
                    .OrderBy(d => d.Id);    // not directly supported on query; must follow .ToList

                return databases;
            }
        }

        public static async Task<Database> CreateDatabase(AppConfig config, string id)
        {
            System.Diagnostics.Debugger.Break();

            var databaseDefinition = new Database { Id = id };
            using (var client = new DocumentClient(new Uri(config.CosmosDbEndpoint), config.CosmosDbMasterKey))
            {
                var result = await client.CreateDatabaseAsync(databaseDefinition);
                var database = result.Resource;

                return database;
            }
        }

        public static async Task DeleteDatabase(AppConfig config, string databaseId)
        {
            System.Diagnostics.Debugger.Break();

            var databaseUri = UriFactory.CreateDatabaseUri(databaseId);
            using (var client = new DocumentClient(new Uri(config.CosmosDbEndpoint), config.CosmosDbMasterKey))
            {
                await client.DeleteDatabaseAsync(databaseUri);
            }
        }

    }
}
