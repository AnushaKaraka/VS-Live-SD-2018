﻿using CosmosDbDemos.Shared;
using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.Documents.Linq;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CosmosDbDemos.DataLayer
{
    public static class SqlApiDocumentsRepo
    {
        public static async Task<object> CreateDocumentFromDynamic(AppConfig config, string databaseId, string collectionId)
        {
            System.Diagnostics.Debugger.Break();

            dynamic documentDefinition = new
            {
                name = "New Customer 1",
                address = new
                {
                    addressType = "Main Office",
                    addressLine1 = "123 Main Street",
                    location = new
                    {
                        city = "Brooklyn",
                        stateProvinceName = "New York"
                    },
                    postalCode = "11229",
                    countryRegionName = "United States"
                },
            };

            var collectionUri = UriFactory.CreateDocumentCollectionUri(databaseId, collectionId);
            using (var client = new DocumentClient(new Uri(config.CosmosDbEndpoint), config.CosmosDbMasterKey))
            {
                var result = await client.CreateDocumentAsync(collectionUri, documentDefinition);
                var document = result.Resource;

                return document;
            }

        }

        public static async Task<object> CreateDocumentFromJson(AppConfig config, string databaseId, string collectionId)
        {
            System.Diagnostics.Debugger.Break();

            var documentDefinition = @"
			{
				""name"": ""New Customer 2"",
				""address"": {
					""addressType"": ""Main Office"",
					""addressLine1"": ""123 Main Street"",
					""location"": {
						""city"": ""Brooklyn"",
						""stateProvinceName"": ""New York""
					},
					""postalCode"": ""11229"",
					""countryRegionName"": ""United States""
				}
			}";

            var documentObject = JsonConvert.DeserializeObject(documentDefinition);
            var collectionUri = UriFactory.CreateDocumentCollectionUri(databaseId, collectionId);
            using (var client = new DocumentClient(new Uri(config.CosmosDbEndpoint), config.CosmosDbMasterKey))
            {
                var result = await client.CreateDocumentAsync(collectionUri, documentObject);
                var document = result.Resource;

                return document;
            }
        }

        public static async Task<object> CreateDocumentFromPoco(AppConfig config, string databaseId, string collectionId)
        {
            System.Diagnostics.Debugger.Break();

            var documentDefinition = new Customer
            {
                Name = "New Customer 3",
                Address = new Address
                {
                    AddressType = "Main Office",
                    AddressLine1 = "123 Main Street",
                    Location = new Location
                    {
                        City = "Brooklyn",
                        StateProvinceName = "New York"
                    },
                    PostalCode = "11229",
                    CountryRegionName = "United States"
                },
            };

            var collectionUri = UriFactory.CreateDocumentCollectionUri(databaseId, collectionId);
            using (var client = new DocumentClient(new Uri(config.CosmosDbEndpoint), config.CosmosDbMasterKey))
            {
                var result = await client.CreateDocumentAsync(collectionUri, documentDefinition);
                var document = result.Resource;

                return document;
            }
        }

        public static IEnumerable<object> QueryForDynamic(AppConfig config, string databaseId, string collectionId)
        {
            System.Diagnostics.Debugger.Break();

            var results = new List<object>();

            var sql = "SELECT * FROM c WHERE STARTSWITH(c.name, 'New Customer') = true";
            var options = new FeedOptions { EnableCrossPartitionQuery = true, EnableScanInQuery = true };

            var collectionUri = UriFactory.CreateDocumentCollectionUri(databaseId, collectionId);
            using (var client = new DocumentClient(new Uri(config.CosmosDbEndpoint), config.CosmosDbMasterKey))
            {
                var documents = client.CreateDocumentQuery(collectionUri, sql, options).ToList();

                foreach (var document in documents)
                {
                    Customer customer = JsonConvert.DeserializeObject<Customer>(document.ToString());
                    dynamic item = new
                    {
                        Id = document.id,
                        Name = document.name,
                        City = customer.Address.Location.City
                    };
                    results.Add(item);
                }
            }

            return results;
        }

        public static IEnumerable<object> QueryForPoco(AppConfig config, string databaseId, string collectionId)
        {
            System.Diagnostics.Debugger.Break();

            var results = new List<object>();

            var sql = "SELECT * FROM c WHERE STARTSWITH(c.name, 'New Customer') = true";
            var options = new FeedOptions { EnableCrossPartitionQuery = true, EnableScanInQuery = true };

            var collectionUri = UriFactory.CreateDocumentCollectionUri(databaseId, collectionId);
            using (var client = new DocumentClient(new Uri(config.CosmosDbEndpoint), config.CosmosDbMasterKey))
            {
                var documents = client.CreateDocumentQuery<Customer>(collectionUri, sql, options).ToList();

                foreach (var customer in documents)
                {
                    dynamic item = new
                    {
                        customer.Id,
                        customer.Name,
                        customer.Address.Location.City
                    };
                    results.Add(item);
                }
            }

            return results;
        }

        public static IEnumerable<object> QueryWithLinq(AppConfig config, string databaseId, string collectionId)
        {
            System.Diagnostics.Debugger.Break();

            var collectionUri = UriFactory.CreateDocumentCollectionUri(databaseId, collectionId);
            var options = new FeedOptions { EnableCrossPartitionQuery = true, EnableScanInQuery = true };

            using (var client = new DocumentClient(new Uri(config.CosmosDbEndpoint), config.CosmosDbMasterKey))
            {
                var q =
                    from d in client.CreateDocumentQuery<Customer>(collectionUri, options)
                    where d.Address.CountryRegionName == "United Kingdom"
                    select new
                    {
                        d.Id,
                        d.Name,
                        d.Address.Location.City
                    };

                var documents = q.ToList();

                return documents;
            }
        }

        public static async Task<PagedResult> QueryWithPaging(AppConfig config, string databaseId, string collectionId, object previousContinuationToken = null)
        {
            System.Diagnostics.Debugger.Break();

            var results = new List<object>();

            var sql = "SELECT * FROM c";
            var options = new FeedOptions
            {
                MaxItemCount = 100,
                EnableCrossPartitionQuery = true,
                EnableScanInQuery = true,
            };

            if (previousContinuationToken != null)
            {
                options.RequestContinuation = previousContinuationToken.ToString();
            }

            var collectionUri = UriFactory.CreateDocumentCollectionUri(databaseId, collectionId);
            using (var client = new DocumentClient(new Uri(config.CosmosDbEndpoint), config.CosmosDbMasterKey))
            {
                var query = client
                    .CreateDocumentQuery<Customer>(collectionUri, sql, options)
                    .AsDocumentQuery();

                var documents = await query.ExecuteNextAsync<Customer>();

                var continuationToken = documents.ResponseContinuation;

                foreach (var customer in documents)
                {
                    dynamic item = new
                    {
                        customer.Id,
                        customer.Name,
                        customer.Address.Location.City
                    };
                    results.Add(item);
                }

                var pagedResult = new PagedResult
                {
                    Data = results,
                    ContinuationToken = continuationToken
                };

                return pagedResult;
            }
        }

        public static async Task<string> ReplaceDocuments(AppConfig config, string databaseId, string collectionId)
        {
            System.Diagnostics.Debugger.Break();

            var sb = new StringBuilder();
            sb.AppendLine(">>> Replace Documents <<<");
            sb.AppendLine();

            var collectionUri = UriFactory.CreateDocumentCollectionUri(databaseId, collectionId);
            var options = new FeedOptions { EnableCrossPartitionQuery = true, EnableScanInQuery = true };

            using (var client = new DocumentClient(new Uri(config.CosmosDbEndpoint), config.CosmosDbMasterKey))
            {
                sb.AppendLine("Querying WHERE c.isNew = true");
                var sql = "SELECT VALUE COUNT(c) FROM c WHERE c.isNew = true";
                var count = client.CreateDocumentQuery(collectionUri, sql, options).AsEnumerable().First();
                sb.AppendLine($"Documents with 'isNew' flag: {count}");
                sb.AppendLine();

                sb.AppendLine("Querying WHERE STARTSWITH(c.name, 'New Customer') = true");
                sql = "SELECT * FROM c WHERE STARTSWITH(c.name, 'New Customer') = true";
                var documents = client.CreateDocumentQuery(collectionUri, sql, options).ToList();
                sb.AppendLine($"Found {documents.Count} documents to be updated");
                foreach (var document in documents)
                {
                    document.isNew = true;
                    var result = await client.ReplaceDocumentAsync(document._self, document);
                    var updatedDocument = result.Resource;
                    sb.AppendLine($"Updated document ID {updatedDocument.id} 'isNew' flag: {updatedDocument.isNew}");
                }
                sb.AppendLine();

                sb.AppendLine("Querying WHERE c.isNew = true");
                sql = "SELECT VALUE COUNT(c) FROM c WHERE c.isNew = true";
                count = client.CreateDocumentQuery(collectionUri, sql, options).AsEnumerable().First();
                sb.AppendLine($"Documents with 'isNew' flag: {count}");
            }

            return sb.ToString();
        }

        public static async Task<string> DeleteDocuments(AppConfig config, string databaseId, string collectionId)
        {
            System.Diagnostics.Debugger.Break();

            var sb = new StringBuilder();
            sb.AppendLine(">>> Delete Documents <<<");
            sb.AppendLine();

            var collectionUri = UriFactory.CreateDocumentCollectionUri(databaseId, collectionId);
            var options = new FeedOptions { EnableCrossPartitionQuery = true, EnableScanInQuery = true };

            using (var client = new DocumentClient(new Uri(config.CosmosDbEndpoint), config.CosmosDbMasterKey))
            {
                var feedOptions = new FeedOptions { EnableCrossPartitionQuery = true };

                sb.AppendLine("Querying WHERE STARTSWITH(c.name, 'New Customer') = true");
                var sql = "SELECT c._self, c.address.postalCode FROM c WHERE STARTSWITH(c.name, 'New Customer') = true";
                var documentKeys = client.CreateDocumentQuery(collectionUri, sql, feedOptions).ToList();

                sb.AppendLine($"Found {documentKeys.Count} documents to be deleted");
                foreach (var documentKey in documentKeys)
                {
                    var requestOptions = new RequestOptions { PartitionKey = new PartitionKey(documentKey.postalCode) };
                    await client.DeleteDocumentAsync(documentKey._self, requestOptions);
                    sb.AppendLine($"Deleted document with self-link '{documentKey._self}' (partition key '{documentKey.postalCode}')");
                }

                sb.AppendLine($"Deleted {documentKeys.Count} new customer documents");
            }

            return sb.ToString();
        }

    }
}
