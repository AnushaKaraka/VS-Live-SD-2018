﻿using CosmosDbDemos.Shared;
using Microsoft.Azure.Documents.Client;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CosmosDbDemos.DataLayer
{
    public static class SqlApiFamiliesRepo
    {
        public static async Task<string> CreateFamiliesCollectionForQueryDemos(AppConfig config)
        {
            if (SqlApiDatabasesRepo.GetDatabases(config).Any(d => d.Id == "Families"))
            {
                await SqlApiDatabasesRepo.DeleteDatabase(config, "Families");
            }

            await SqlApiDatabasesRepo.CreateDatabase(config, "Families");
            await SqlApiCollectionsRepo.CreateCollection(config, "Families", "Families", "/location/state", 400);

            var docs = GetQueryDemoDocuments();

            var collectionUri = UriFactory.CreateDocumentCollectionUri("Families", "Families");
            using (var client = new DocumentClient(new Uri(config.CosmosDbEndpoint), config.CosmosDbMasterKey))
            {
                foreach (var doc in docs)
                {
                    var documentObject = JsonConvert.DeserializeObject(doc);
                    await client.CreateDocumentAsync(collectionUri, documentObject);
                }
            }

            return "Successfully created Families collection for SQL Query demos";
        }

        private static IEnumerable<string> GetQueryDemoDocuments()
        {
            var andersen = @"
                {
	                ""id"": ""AndersenFamily"",
                    ""lastName"": ""Andersen"",
	                ""parents"": [
		                {
			                ""firstName"": ""Thomas"",
			                ""relationship"": ""father""

                        },
		                {
			                ""firstName"": ""Mary Kay"",
			                ""relationship"": ""mother""
		                }
	                ],
	                ""children"": [
		                {
			                ""firstName"": ""Henriette Thaulow"",
			                ""gender"": ""female"",
			                ""grade"": 5,
			                ""pets"": [
				                {
					                ""givenName"": ""Fluffy"",
					                ""type"": ""Rabbit""
				                }
			                ]
		                }
	                ],
	                ""location"": {
		                ""state"": ""WA"",
		                ""county"": ""King"",
		                ""city"": ""Seattle""
	                },
	                ""geo"": {
		                ""type"": ""Point"",
		                ""coordinates"": [ -122.3295, 47.60357 ]
	                },
	                ""isRegistered"": true
                }
            ";

            var smith = @"
                {
	                ""id"": ""SmithFamily"",
                    ""parents"": [
		                {
			                ""familyName"": ""Smith"",
			                ""givenName"": ""James""

                        },
		                {
			                ""familyName"": ""Curtis"",
			                ""givenName"": ""Helen""
		                }
	                ],
	                ""children"": [
		                {
			                ""givenName"": ""Michelle"",
			                ""gender"": ""female"",
			                ""grade"": 1
		                },
		                {
			                ""givenName"": ""John"",
			                ""gender"": ""male"",
			                ""grade"": 7,
			                ""pets"": [
				                {
					                ""givenName"": ""Tweetie"",
					                ""type"": ""Bird""
				                }
			                ]
		                }
	                ],
	                ""location"": {
		                ""state"": ""NY"",
		                ""county"": ""Queens"",
		                ""city"": ""Forest Hills""
	                },
	                ""geo"": {
		                ""type"": ""Point"",
		                ""coordinates"": [ -73.84791, 40.72266 ]
	                },
	                ""isRegistered"": true
                }
            ";

            var wakefield = @"
                {
	                ""id"": ""WakefieldFamily"",

                    ""parents"": [
		                {
			                ""familyName"": ""Wakefield"",
			                ""givenName"": ""Robin""

                        },
		                {
			                ""familyName"": ""Miller"",
			                ""givenName"": ""Ben""
		                }
	                ],
	                ""children"": [
		                {
			                ""familyName"": ""Merriam"",
			                ""givenName"": ""Jesse"",
			                ""gender"": ""female"",
			                ""grade"": 6,
			                ""pets"": [
				                {
					                ""givenName"": ""Charlie Brown"",
					                ""type"": ""Dog""
				                },
				                {
					                ""givenName"": ""Tiger"",
					                ""type"": ""Cat""
				                },
				                {
					                ""givenName"": ""Princess"",
					                ""type"": ""Cat""
				                }
			                ]
		                },
		                {
			                ""familyName"": ""Miller"",
			                ""givenName"": ""Lisa"",
			                ""gender"": ""female"",
			                ""grade"": 3,
			                ""pets"": [
				                {
					                ""givenName"": ""Jake"",
					                ""type"": ""Snake""
				                }
			                ]
		                }
	                ],
	                ""location"": {
		                ""state"": ""NY"",
		                ""county"": ""Manhattan"",
		                ""city"": ""NY""
	                },
	                ""geo"": {
		                ""type"": ""Point"",
		                ""coordinates"": [ -73.992, 40.73100 ]
	                },
	                ""isRegistered"": false
                }
            ";

            var documents = new List<string>()
            {
                andersen,
                smith,
                wakefield
            };

            return documents;
        }

        public static async Task<string> CreateFamiliesCollectionForGlobalDistDemos(AppConfig config)
        {
            if (SqlApiDatabasesRepo.GetDatabases(config).Any(d => d.Id == "Families"))
            {
                await SqlApiDatabasesRepo.DeleteDatabase(config, "Families");
            }

            await SqlApiDatabasesRepo.CreateDatabase(config, "Families");
            await SqlApiCollectionsRepo.CreateCollection(config, "Families", "Families", "/address/zipCode", 400);

            var docs = GetQueryDemoDocuments();

            var collectionUri = UriFactory.CreateDocumentCollectionUri("Families", "Families");
            using (var client = new DocumentClient(new Uri(config.CosmosDbEndpoint), config.CosmosDbMasterKey))
            {
                dynamic documentDef = new
                {
                    familyName = "Jones",
                    address = new
                    {
                        addressLine = "456 Harbor Boulevard",
                        city = "Chicago",
                        state = "IL",
                        zipCode = "60603"
                    },
                    parents = new string[]
                    {
                        "David",
                        "Diana"
                    },
                    kids = new string[]
                    {
                        "Evan"
                    },
                    pets = new string[]
                    {
                        "Lint"
                    }
                };

                await client.CreateDocumentAsync(collectionUri, documentDef);
            }

            return "Successfully created Families collection for Global Distribution demos";
        }


    }
}
