﻿using CosmosDbDemos.Shared;
using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CosmosDbDemos.DataLayer
{
    public static class SqlApiIndexingRepo
    {
        public async static Task<string> AutomaticIndexing(AppConfig config)
        {
            System.Diagnostics.Debugger.Break();

            var sb = new StringBuilder();
            sb.AppendLine(">>> Override Automatic Indexing <<<");
            sb.AppendLine();

            using (var client = new DocumentClient(new Uri(config.CosmosDbEndpoint), config.CosmosDbMasterKey))
            {
                // Create collection with automatic indexing
                var partitionKeyDefinition = new PartitionKeyDefinition();
                partitionKeyDefinition.Paths.Add("/id");
                var collectionDefinition = new DocumentCollection
                {
                    Id = "autoindexing",
                    PartitionKey = partitionKeyDefinition
                };
                var options = new RequestOptions { OfferThroughput = 1000 };
                var databaseUri = UriFactory.CreateDatabaseUri("mydb");
                var collection = await client.CreateDocumentCollectionAsync(databaseUri, collectionDefinition, options);
                var collectionUri = UriFactory.CreateDocumentCollectionUri("mydb", "autoindexing");
                sb.AppendLine("Created collection with automatic indexing enabled");

                // Add a document (indexed)
                dynamic indexedDocumentDefinition = new
                {
                    id = "JOHN",
                    firstName = "John",
                    lastName = "Doe",
                    addressLine = "123 Main Street",
                    city = "Brooklyn",
                    state = "New York",
                    zip = "11229",
                };
                Document indexedDocument = await client.CreateDocumentAsync(collectionUri, indexedDocumentDefinition);
                sb.AppendLine("Created indexed document for 'John Doe'");

                // Add another document (request no indexing)
                dynamic unindexedDocumentDefinition = new
                {
                    id = "JANE",
                    firstName = "Jane",
                    lastName = "Doe",
                    addressLine = "123 Main Street",
                    city = "Brooklyn",
                    state = "New York",
                    zip = "11229",
                };
                var requestOptions = new RequestOptions { IndexingDirective = IndexingDirective.Exclude };
                Document unindexedDocument = await client.CreateDocumentAsync(collectionUri, unindexedDocumentDefinition, requestOptions);
                sb.AppendLine("Created unindexed document for 'Jane Doe'");
                sb.AppendLine();

                var feedOptions = new FeedOptions { EnableCrossPartitionQuery = true };

                // Unindexed document won't get returned when querying on non-ID (or self-link) property

                var doeDocs = client
                    .CreateDocumentQuery(collectionUri, "SELECT * FROM c WHERE c.lastName = 'Doe'", feedOptions)
                    .ToList();

                sb.AppendLine($"Query WHERE lastName = 'Doe': {doeDocs.Count}");
                foreach (var doeDoc in doeDocs)
                {
                    sb.AppendLine($" ID: {doeDoc.id}, Name: {doeDoc.firstName} {doeDoc.lastName}");
                }
                sb.AppendLine();

                // Unindexed document will get returned when using no WHERE clause
                var allDocs = client.CreateDocumentQuery(collectionUri, "SELECT * FROM c", feedOptions).ToList();
                sb.AppendLine($"Query with no WHERE clause (all documents): {allDocs.Count}");
                foreach (var doc in allDocs)
                {
                    sb.AppendLine($" ID: {doc.id}, Name: {doc.firstName} {doc.lastName}");
                }
                sb.AppendLine();

                // Unindexed document will get returned when querying by ID (or self-link) property
                var janeDoc = client
                    .CreateDocumentQuery(collectionUri, "SELECT * FROM c WHERE c.id = 'JANE'", feedOptions)
                    .AsEnumerable()
                    .FirstOrDefault();

                sb.AppendLine($"Query unindexed document WHERE id = 'JANE':");
                sb.AppendLine($" ID: {janeDoc.id}, Name: {janeDoc.firstName} {janeDoc.lastName}");

                // Delete the collection
                await client.DeleteDocumentCollectionAsync(collectionUri);
            }

            return sb.ToString();
        }

        public async static Task<string> ManualIndexing(AppConfig config)
        {
            System.Diagnostics.Debugger.Break();

            var sb = new StringBuilder();
            sb.AppendLine(">>> Manual Indexing <<<");
            sb.AppendLine();

            using (var client = new DocumentClient(new Uri(config.CosmosDbEndpoint), config.CosmosDbMasterKey))
            {
                // Create collection with manual indexing
                var partitionKeyDefinition = new PartitionKeyDefinition();
                partitionKeyDefinition.Paths.Add("/id");
                var collectionDefinition = new DocumentCollection
                {
                    Id = "manualindexing",
                    PartitionKey = partitionKeyDefinition,
                    IndexingPolicy = new IndexingPolicy
                    {
                        Automatic = false,
                    },
                };
                var options = new RequestOptions { OfferThroughput = 1000 };
                var databaseUri = UriFactory.CreateDatabaseUri("mydb");
                var collection = await client.CreateDocumentCollectionAsync(databaseUri, collectionDefinition, options);
                var collectionUri = UriFactory.CreateDocumentCollectionUri("mydb", "manualindexing");
                sb.AppendLine("Created collection with automatic indexing disabled");

                // Add a document (unindexed)
                dynamic unindexedDocumentDefinition = new
                {
                    id = "JOHN",
                    firstName = "John",
                    lastName = "Doe",
                    addressLine = "123 Main Street",
                    city = "Brooklyn",
                    state = "New York",
                    zip = "11229",
                };
                Document unindexedDocument = await client.CreateDocumentAsync(collectionUri, unindexedDocumentDefinition);
                sb.AppendLine("Created unindexed document for 'John Doe'");

                // Add another document (request indexing)
                dynamic indexedDocumentDefinition = new
                {
                    id = "JANE",
                    firstName = "Jane",
                    lastName = "Doe",
                    addressLine = "123 Main Street",
                    city = "Brooklyn",
                    state = "New York",
                    zip = "11229",
                };
                var requestOptions = new RequestOptions { IndexingDirective = IndexingDirective.Include };
                Document indexedDocument = await client.CreateDocumentAsync(collectionUri, indexedDocumentDefinition, requestOptions);
                sb.AppendLine("Created indexed document for 'Jane Doe'");
                sb.AppendLine();

                var feedOptions = new FeedOptions { EnableCrossPartitionQuery = true };

                // Unindexed document won't get returned when querying on non-ID (or self-link) property
                var doeDocs = client
                    .CreateDocumentQuery(collectionUri, "SELECT * FROM c WHERE c.lastName = 'Doe'", feedOptions)
                    .ToList();

                sb.AppendLine($"Query WHERE lastName = 'Doe': {doeDocs.Count}");
                foreach (var doeDoc in doeDocs)
                {
                    sb.AppendLine($" ID: {doeDoc.id}, Name: {doeDoc.firstName} {doeDoc.lastName}");
                }
                sb.AppendLine();

                // Unindexed document will get returned when using no WHERE clause
                var allDocs = client.CreateDocumentQuery(collectionUri, "SELECT * FROM c", feedOptions).ToList();
                sb.AppendLine($"Query with no WHERE clause (all documents): {allDocs.Count}");
                foreach (var doc in allDocs)
                {
                    sb.AppendLine($" ID: {doc.id}, Name: {doc.firstName} {doc.lastName}");
                }
                sb.AppendLine();

                // Unindexed document will get returned when querying by ID (or self-link) property
                var johnDoc = client
                    .CreateDocumentQuery(collectionUri, "SELECT * FROM c WHERE c.id = 'JOHN'")
                    .AsEnumerable()
                    .FirstOrDefault();

                sb.AppendLine($"Query unindexed document WHERE id = 'JOHN':");
                sb.AppendLine($" ID: {johnDoc.id}, Name: {johnDoc.firstName} {johnDoc.lastName}");

                // Delete the collection
                await client.DeleteDocumentCollectionAsync(collectionUri);

                return sb.ToString();
            }
        }

        public async static Task<string> PathIndexing(AppConfig config)
        {
            System.Diagnostics.Debugger.Break();

            var sb = new StringBuilder();
            sb.AppendLine(">>> Set Custom Index Paths <<<");
            sb.AppendLine();

            using (var client = new DocumentClient(new Uri(config.CosmosDbEndpoint), config.CosmosDbMasterKey))
            {
                // Create collection with custom indexing paths
                var partitionKeyDefinition = new PartitionKeyDefinition();
                partitionKeyDefinition.Paths.Add("/id");
                var collectionDefinition = new DocumentCollection
                {
                    Id = "customindexing",
                    PartitionKey = partitionKeyDefinition,
                    IndexingPolicy = new IndexingPolicy
                    {
                        IncludedPaths = new Collection<IncludedPath>
                        {
						    // The Title property in the root is the only string property we need to sort on
						    new IncludedPath
                            {
                                Path = "/title/?",
                                Indexes = new Collection<Index>
                                {
                                    new RangeIndex(DataType.String)
                                }
                            },
						    // Every property (also the Title) gets a hash index on strings, and a range index on numbers
						    new IncludedPath
                            {
                                Path = "/*",
                                Indexes = new Collection<Index>
                                {
                                    new HashIndex(DataType.String),
                                    new RangeIndex(DataType.Number),
                                }
                            }
                        },
                        ExcludedPaths = new Collection<ExcludedPath>
                        {
                            new ExcludedPath
                            {
                                Path = "/misc/*",
                            }
                        }
                    },
                };
                var options = new RequestOptions { OfferThroughput = 1000 };
                var databaseUri = UriFactory.CreateDatabaseUri("mydb");
                var collection = await client.CreateDocumentCollectionAsync(databaseUri, collectionDefinition, options);
                var collectionUri = UriFactory.CreateDocumentCollectionUri("mydb", "customindexing");
                sb.AppendLine("Created collection with custom index paths");

                // Add some documents
                dynamic doc1Definition = new
                {
                    id = "SW4",
                    title = "Star Wars IV - A New Hope",
                    rank = 600,
                    category = "Sci-Fi",
                    misc = new
                    {
                        year = 1977,
                        length = "2hr 1min"
                    }
                };
                Document doc1 = await client.CreateDocumentAsync(collectionUri, doc1Definition);
                sb.AppendLine($"Created document '{doc1.Id}'");

                dynamic doc2Definition = new
                {
                    id = "GF",
                    title = "Godfather",
                    rank = 500,
                    category = "Crime Drama",
                    misc = new
                    {
                        year = 1972,
                        length = "2hr 55min"
                    }
                };
                Document doc2 = await client.CreateDocumentAsync(collectionUri, doc2Definition);
                sb.AppendLine($"Created document '{doc2.Id}'");

                dynamic doc3Definition = new
                {
                    id = "LOTR1",
                    title = "Lord Of The Rings - Fellowship of the Ring",
                    rank = 700,
                    category = "Fantasy",
                    misc = new
                    {
                        year = 2001,
                        length = "2hr 58min"
                    }
                };
                Document doc3 = await client.CreateDocumentAsync(collectionUri, doc3Definition);
                sb.AppendLine($"Created document '{doc3.Id}'");

                // All the queries in this demo are cross-partition queries
                var allowCrossPartitionQuery = new FeedOptions { EnableCrossPartitionQuery = true };

                // When trying a range query when a range index is not availalbe, must also explicitly enable scan in query
                var allowCrossPartitionAndScanQuery = new FeedOptions { EnableCrossPartitionQuery = true, EnableScanInQuery = true };


                // *** Querying (WHERE) ***

                // Equality on title string property (range and hash index available)
                var sql = "SELECT * FROM c WHERE c.title = 'Godfather'";
                var queryByTitle = client.CreateDocumentQuery(collectionUri, sql, allowCrossPartitionQuery).ToList();
                sb.AppendLine();
                sb.AppendLine($"Query WHERE c.title = 'Godfather' (string, hash and range index): {queryByTitle.Count}");

                // Equality on category string property (hash index available)
                sb.AppendLine();
                sql = "SELECT * FROM c WHERE c.category = 'Fantasy'";
                var queryByCategory = client.CreateDocumentQuery(collectionUri, sql, allowCrossPartitionQuery).ToList();
                sb.AppendLine($"Query WHERE c.category = 'Fantasy' (string, hash index): {queryByTitle.Count}");

                // Range on category string property (hash index can't be used, no range index available)
                sql = "SELECT * FROM c WHERE c.category >= 'Fantasy'";
                try
                {
                    sb.AppendLine($"Query WHERE c.category >= 'Fantasy' (string, no range index)");
                    var queryByCategoryRange = client.CreateDocumentQuery(collectionUri, sql, allowCrossPartitionQuery).ToList();
                }
                catch (AggregateException aex)
                {
                    if (aex.InnerException is DocumentClientException dcex)
                    {
                        sb.AppendLine($"EXCEPTION: {dcex.Message.Substring(0, dcex.Message.IndexOf(Environment.NewLine))}");
                        var queryByCategoryRange = client.CreateDocumentQuery(collectionUri, sql, allowCrossPartitionAndScanQuery).ToList();
                        sb.AppendLine($"Query WHERE c.category >= 'Fantasy' (string, no range index, enable scan): {queryByTitle.Count}");
                    }
                }

                // Equality on rank number property (range index available)
                sql = "SELECT * FROM c WHERE c.rank = 500";
                var queryByRank = client.CreateDocumentQuery(collectionUri, sql, allowCrossPartitionQuery).ToList();
                sb.AppendLine();
                sb.AppendLine($"Query WHERE c.rank = 500 (number, range index): {queryByTitle.Count}");

                // Range on rank number property (range index available)
                sql = "SELECT * FROM c WHERE c.rank > 500";
                var queryByRankRange = client.CreateDocumentQuery(collectionUri, sql, allowCrossPartitionQuery).ToList();
                sb.AppendLine($"Query WHERE c.rank > 500 (number, range index): {queryByTitle.Count}");

                // Equality on year number property (no index available; scan required)
                sql = "SELECT * FROM c WHERE c.misc.year = 2001";
                try
                {
                    sb.AppendLine();
                    sb.AppendLine($"Query WHERE c.misc.year = 2001 (number, no index)");
                    var queryByYear = client.CreateDocumentQuery(collectionUri, sql, allowCrossPartitionQuery).ToList();
                }
                catch (AggregateException aex)
                {
                    if (aex.InnerException is DocumentClientException dcex)
                    {
                        sb.AppendLine($"EXCEPTION: {dcex.Message.Substring(0, dcex.Message.IndexOf(Environment.NewLine))}");
                        var queryByYear = client.CreateDocumentQuery(collectionUri, sql, allowCrossPartitionAndScanQuery).ToList();
                        sb.AppendLine($"Query WHERE c.misc.year = 2001 (number, no index, enable scan): {queryByYear.Count}");
                    }
                }

                // Equality on length string property (no index available; scan required)
                sql = "SELECT * FROM c WHERE c.misc.length = '2hr 58min'";
                try
                {
                    sb.AppendLine();
                    sb.AppendLine($"Query WHERE c.misc.length = '2hr 58min' (string, no index)");
                    var queryByLength = client.CreateDocumentQuery(collectionUri, sql, allowCrossPartitionQuery).ToList();
                }
                catch (AggregateException aex)
                {
                    if (aex.InnerException is DocumentClientException dcex)
                    {
                        sb.AppendLine($"EXCEPTION: {dcex.Message.Substring(0, dcex.Message.IndexOf(Environment.NewLine))}");
                        var queryByLength = client.CreateDocumentQuery(collectionUri, sql, allowCrossPartitionAndScanQuery).ToList();
                        sb.AppendLine($"Query WHERE c.misc.length = '2hr 58min' (string, no index, enable scan): {queryByLength.Count}");
                    }
                }


                // *** Sorting (ORDER BY) ***

                sb.AppendLine();

                // Works with range index on title property strings
                sql = "SELECT * FROM c ORDER BY c.title";
                var sortByTitle = client.CreateDocumentQuery(collectionUri, sql, allowCrossPartitionQuery).ToList();
                sb.AppendLine($"Query ORDER BY c.title (string, range index): {sortByTitle.Count}");

                // Doesn't works without range index on category property strings (returns 0 documents, but doesn't throw error!)
                sql = "SELECT * FROM c ORDER BY c.category";
                var sortByCategory = client.CreateDocumentQuery(collectionUri, sql, allowCrossPartitionQuery).ToList();
                sb.AppendLine($"Query ORDER BY c.category (string, no range index): {sortByCategory.Count}");

                // Works with range index on rank property numbers
                sql = "SELECT * FROM c ORDER BY c.rank";
                var sortByRank = client.CreateDocumentQuery(collectionUri, sql, allowCrossPartitionQuery).ToList();
                sb.AppendLine($"Query ORDER BY c.rank (number, range index): {sortByRank.Count}");

                // Delete the collection
                await client.DeleteDocumentCollectionAsync(collectionUri);
            }

            return sb.ToString();
        }

    }
}
