﻿using CosmosDbDemos.Shared;
using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CosmosDbDemos.DataLayer
{
    public static class SqlApiSecurityRepo
    {
        public static IEnumerable<User> GetUsers(AppConfig config)
        {
            System.Diagnostics.Debugger.Break();

            var databaseUri = UriFactory.CreateDatabaseUri("mydb");

            using (var client = new DocumentClient(new Uri(config.CosmosDbEndpoint), config.CosmosDbMasterKey))
            {
                var users = client
                    .CreateUserQuery(databaseUri)
                    .ToList()
                    .OrderBy(d => d.Id);    // not directly supported on query; must follow .ToList

                return users;
            }
        }

        public static async Task<string> CreateUsers(AppConfig config)
        {
            System.Diagnostics.Debugger.Break();

            var sb = new StringBuilder();
            sb.AppendLine(">>> Create Users <<<");
            sb.AppendLine();

            var databaseUri = UriFactory.CreateDatabaseUri("mydb");

            using (var client = new DocumentClient(new Uri(config.CosmosDbEndpoint), config.CosmosDbMasterKey))
            {
                var userDefinition = new User { Id = "Alice" };
                var result = await client.CreateUserAsync(databaseUri, userDefinition);
                sb.AppendLine($"Created user: '{result.Resource.Id}'");

                userDefinition = new User { Id = "Tom" };
                result = await client.CreateUserAsync(databaseUri, userDefinition);
                sb.AppendLine($"Created user: '{result.Resource.Id}'");
            }

            return sb.ToString();
        }

        public static async Task<object> CreatePermissions(AppConfig config)
        {
            System.Diagnostics.Debugger.Break();

            var sb = new StringBuilder();
            sb.AppendLine(">>> Create Permissions <<<");
            sb.AppendLine();

            var databaseUri = UriFactory.CreateDatabaseUri("mydb");

            using (var client = new DocumentClient(new Uri(config.CosmosDbEndpoint), config.CosmosDbMasterKey))
            {
                var sql = "SELECT VALUE c._self FROM c WHERE c.id = 'mystore'";
                string collectionSelfLink = client.CreateDocumentCollectionQuery(databaseUri, sql).AsEnumerable().First().Value;

                var alicePerm = await CreatePermission(client, sb, "Alice", "AliceCollectionAccess", PermissionMode.All, collectionSelfLink);
                var tomPerm = await CreatePermission(client, sb, "Tom", "TomCollectionAccess", PermissionMode.Read, collectionSelfLink);

                dynamic result = new
                {
                    alicePerm,
                    tomPerm,
                    output = sb.ToString(),
                };

                return result;
            }
        }

        private static async Task<Permission> CreatePermission(DocumentClient client, StringBuilder sb, string userId, string permissionId, PermissionMode permissionMode, string resourceLink)
        {
            sb.AppendLine();
            sb.AppendLine($">>> Create Permission {permissionId} for {userId} <<<");

            var databaseUri = UriFactory.CreateDatabaseUri("mydb");
            var sql = $"SELECT VALUE c._self FROM c WHERE c.id = '{userId}'";
            string userSelfLink = client.CreateUserQuery(databaseUri, sql).AsEnumerable().First().Value;

            var permDefinition = new Permission { Id = permissionId, PermissionMode = permissionMode, ResourceLink = resourceLink };
            var result = await client.CreatePermissionAsync(userSelfLink, permDefinition);
            var perm = result.Resource;

            sb.AppendLine($"Created new permission '{permissionId}' on 'mystore' collection ('{resourceLink}') with access '{permissionMode}' for user '{userId}'");

            return perm;
        }

        public static IEnumerable<Permission> GetPermissions(AppConfig config, string userId)
        {
            System.Diagnostics.Debugger.Break();

            var databaseUri = UriFactory.CreateDatabaseUri("mydb");

            using (var client = new DocumentClient(new Uri(config.CosmosDbEndpoint), config.CosmosDbMasterKey))
            {
                var sql = $"SELECT VALUE c._self FROM c WHERE c.id = '{userId}'";

                string userSelfLink = client
                    .CreateUserQuery(databaseUri, sql)
                    .AsEnumerable()
                    .First()
                    .Value;

                var permissionsLink = $"{userSelfLink}permissions/";

                var permissions = client
                    .CreatePermissionQuery(permissionsLink)
                    .ToList()
                    .OrderBy(p => p.Id);    // not directly supported on query; must follow .ToList

                return permissions;
            }
        }

        public static async Task<string> TestPermissions(AppConfig config, string userId)
        {
            System.Diagnostics.Debugger.Break();

            var sb = new StringBuilder();
            sb.AppendLine(">>> Test Permissions <<<");
            sb.AppendLine();

            var databaseUri = UriFactory.CreateDatabaseUri("mydb");

            using (var client = new DocumentClient(new Uri(config.CosmosDbEndpoint), config.CosmosDbMasterKey))
            {
                var sql = "SELECT VALUE c._self FROM c WHERE c.id = 'mystore'";
                string collectionSelfLink = client.CreateDocumentCollectionQuery(databaseUri, sql).AsEnumerable().First().Value;

                sql = $"SELECT VALUE c._self FROM c WHERE c.id = '{userId}'";
                string userSelfLink = client.CreateUserQuery(databaseUri, sql).AsEnumerable().First().Value;
                var permissionsLink = $"{userSelfLink}permissions/";

                var permission = client.CreatePermissionQuery(permissionsLink)
                    .AsEnumerable()
                    .First(p => p.ResourceLink == collectionSelfLink);

                sb.AppendLine();
                sb.AppendLine($"Trying to create & delete document as user {userId}");

                var output = await TestPermissions(config.CosmosDbEndpoint, permission);
                sb.Append(output);
            }

            return sb.ToString();
        }

        private static async Task<string> TestPermissions(string endpoint, Permission permission)
        {
            var sb = new StringBuilder();

            dynamic documentDefinition = new
            {
                name = "New Customer 1",
                address = new
                {
                    addressType = "Main Office",
                    addressLine1 = "123 Main Street",
                    location = new
                    {
                        city = "Brooklyn",
                        stateProvinceName = "New York"
                    },
                    postalCode = "11229",
                    countryRegionName = "United States"
                },
            };


            var resourceToken = permission.Token;
            var collectionUri = UriFactory.CreateDocumentCollectionUri("mydb", "mystore");

            try
            {
                using (var restrictedClient = new DocumentClient(new Uri(endpoint), resourceToken))
                {
                    var document = await restrictedClient.CreateDocumentAsync(collectionUri, documentDefinition);
                    sb.AppendLine($"Successfully created document: {document.Resource.id}");

                    var options = new RequestOptions { PartitionKey = new PartitionKey("11229") };
                    await restrictedClient.DeleteDocumentAsync(document.Resource._self, options);
                    sb.AppendLine($"Successfully deleted document: {document.Resource.id}");
                }
            }
            catch (Exception ex)
            {
                sb.AppendLine($"ERROR: {ex.Message}");
            }

            return sb.ToString();
        }

        private static async Task<string> TestPermissions(string endpoint, IList<Permission> permissions)
        {
            var sb = new StringBuilder();

            dynamic documentDefinition = new
            {
                name = "New Customer 1",
                address = new
                {
                    addressType = "Main Office",
                    addressLine1 = "123 Main Street",
                    location = new
                    {
                        city = "Brooklyn",
                        stateProvinceName = "New York"
                    },
                    postalCode = "11229",
                    countryRegionName = "United States"
                },
            };

            var collectionUri = UriFactory.CreateDocumentCollectionUri("mydb", "mystore");

            try
            {
                using (var restrictedClient = new DocumentClient(new Uri(endpoint), permissions))
                {
                    var document = await restrictedClient.CreateDocumentAsync(collectionUri, documentDefinition);
                    sb.AppendLine($"Successfully created document: {document.Resource.id}");

                    var options = new RequestOptions { PartitionKey = new PartitionKey("11229") };
                    await restrictedClient.DeleteDocumentAsync(document.Resource._self, options);
                    sb.AppendLine($"Successfully deleted document: {document.Resource.id}");
                }
            }
            catch (Exception ex)
            {
                sb.AppendLine($"ERROR: {ex.Message}");
            }

            return sb.ToString();
        }

        public static async Task<string> DeleteUsers(AppConfig config)
        {
            System.Diagnostics.Debugger.Break();

            var sb = new StringBuilder();
            sb.AppendLine(">>> Delete Users <<<");
            sb.AppendLine();

            using (var client = new DocumentClient(new Uri(config.CosmosDbEndpoint), config.CosmosDbMasterKey))
            {
                var userUri = UriFactory.CreateUserUri("mydb", "Alice");
                await client.DeleteUserAsync(userUri);  // also deletes child permissions
                sb.AppendLine($"Deleted user: 'Alice' (with permissions)");

                userUri = UriFactory.CreateUserUri("mydb", "Tom");
                await client.DeleteUserAsync(userUri);  // also deletes child permissions
                sb.AppendLine($"Deleted user: 'Tom' (with permissions)");
            }

            return sb.ToString();
        }

    }
}
