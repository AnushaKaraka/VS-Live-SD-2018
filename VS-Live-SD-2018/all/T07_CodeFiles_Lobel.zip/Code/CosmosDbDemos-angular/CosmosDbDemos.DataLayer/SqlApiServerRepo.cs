﻿using CosmosDbDemos.Shared;
using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CosmosDbDemos.DataLayer
{
    public static class SqlApiServerRepo
    {
        #region "Stored Procedures"

        public static IEnumerable<StoredProcedure> GetStoredProcedures(AppConfig config)
        {
            System.Diagnostics.Debugger.Break();

            var collectionUri = UriFactory.CreateDocumentCollectionUri("mydb", "mystore");

            using (var client = new DocumentClient(new Uri(config.CosmosDbEndpoint), config.CosmosDbMasterKey))
            {
                var sprocs = client
                    .CreateStoredProcedureQuery(collectionUri)
                    .ToList()
                    .OrderBy(sp => sp.Id);    // not directly supported on query; must follow .ToList

                return sprocs;
            }
        }

        public static async Task<string> CreateStoredProcedures(AppConfig config)
        {
            System.Diagnostics.Debugger.Break();

            var sb = new StringBuilder();

            sb.AppendLine(">>> Create Stored Procedures <<<");
            sb.AppendLine();

            using (var client = new DocumentClient(new Uri(config.CosmosDbEndpoint), config.CosmosDbMasterKey))
            {
                await CreateStoredProcedure(client, sb, "spHelloWorld");
                await CreateStoredProcedure(client, sb, "spSetNorthAmerica");
                await CreateStoredProcedure(client, sb, "spEnsureUniqueId");
                await CreateStoredProcedure(client, sb, "spBulkInsert");
                await CreateStoredProcedure(client, sb, "spBulkDelete");
            }

            return sb.ToString();
        }

        private async static Task<StoredProcedure> CreateStoredProcedure(DocumentClient client, StringBuilder sb, string sprocId)
        {
            var sprocBody = File.ReadAllText($@".\Server\{sprocId}.js");

            var sprocDefinition = new StoredProcedure
            {
                Id = sprocId,
                Body = sprocBody
            };

            var collectionUri = UriFactory.CreateDocumentCollectionUri("mydb", "mystore");
            var result = await client.CreateStoredProcedureAsync(collectionUri, sprocDefinition);
            var sproc = result.Resource;
            sb.AppendLine($"Created stored procedure {sproc.Id}; RID: {sproc.ResourceId}");

            return result;
        }

        public static async Task<string> ExecuteStoredProcedure(AppConfig config, string sprocId)
        {
            System.Diagnostics.Debugger.Break();

            var sb = new StringBuilder();

            sb.AppendLine($">>> Execute Stored Procedure {sprocId} <<<");
            sb.AppendLine();

            using (var client = new DocumentClient(new Uri(config.CosmosDbEndpoint), config.CosmosDbMasterKey))
            {
                switch (sprocId)
                {
                    case "spHelloWorld":
                        await Execute_spHelloWorld(client, sb);
                        break;

                    case "spSetNorthAmerica":
                        await Execute_spSetNorthAmerica1(client, sb);
                        await Execute_spSetNorthAmerica2(client, sb);
                        await Execute_spSetNorthAmerica3(client, sb);
                        break;

                    case "spEnsureUniqueId":
                        await Execute_spEnsureUniqueId(client, sb);
                        break;

                    case "spBulkInsert":
                        await Execute_spBulkInsert(client, sb);
                        break;

                    case "spBulkDelete":
                        await Execute_spBulkDelete(client, sb);
                        break;
                }
            }

            return sb.ToString();
        }

        private async static Task Execute_spHelloWorld(DocumentClient client, StringBuilder sb)
        {
            sb.AppendLine("Execute spHelloWorld stored procedure");

            var uri = UriFactory.CreateStoredProcedureUri("mydb", "mystore", "spHelloWorld");
            var options = new RequestOptions { PartitionKey = new PartitionKey(string.Empty) };
            var result = await client.ExecuteStoredProcedureAsync<string>(uri, options);
            var message = result.Response;

            sb.AppendLine($"Result: {message}");
        }

        private async static Task Execute_spSetNorthAmerica1(DocumentClient client, StringBuilder sb)
        {
            sb.AppendLine("Execute spSetNorthAmerica (country = United States)");

            // Should succeed with isNorthAmerica = true
            dynamic documentDefinition = new
            {
                name = "John Doe",
                address = new
                {
                    countryRegionName = "United States",
                    postalCode = "12345"
                }
            };
            var uri = UriFactory.CreateStoredProcedureUri("mydb", "mystore", "spSetNorthAmerica");
            var options = new RequestOptions { PartitionKey = new PartitionKey("12345") };
            var result = await client.ExecuteStoredProcedureAsync<object>(uri, options, documentDefinition, true);
            var document = result.Response;

            var id = document.id;
            var country = document.address.countryRegionName;
            var isNA = document.address.isNorthAmerica;

            sb.AppendLine("Result:");
            sb.AppendLine($" Id = {id}");
            sb.AppendLine($" Country = {country}");
            sb.AppendLine($" Is North America = {isNA}");

            string documentLink = document._self;
            await client.DeleteDocumentAsync(documentLink, options);
        }

        private async static Task Execute_spSetNorthAmerica2(DocumentClient client, StringBuilder sb)
        {
            sb.AppendLine();
            sb.AppendLine("Execute spSetNorthAmerica (country = United Kingdom)");

            // Should succeed with isNorthAmerica = false
            dynamic documentDefinition = new
            {
                name = "John Doe",
                address = new
                {
                    countryRegionName = "United Kingdom",
                    postalCode = "RG41 1QW"
                }
            };
            var uri = UriFactory.CreateStoredProcedureUri("mydb", "mystore", "spSetNorthAmerica");
            var options = new RequestOptions { PartitionKey = new PartitionKey("RG41 1QW") };
            var result = await client.ExecuteStoredProcedureAsync<object>(uri, options, documentDefinition, true);
            var document = result.Response;

            // Deserialize new document as JObject (use dictionary-style indexers to access dynamic properties)
            var documentObject = JsonConvert.DeserializeObject(document.ToString());

            var id = documentObject["id"];
            var country = documentObject["address"]["countryRegionName"];
            var isNA = documentObject["address"]["isNorthAmerica"];

            sb.AppendLine("Result:");
            sb.AppendLine($" Id = {id}");
            sb.AppendLine($" Country = {country}");
            sb.AppendLine($" Is North America = {isNA}");

            string documentLink = document._self;
            await client.DeleteDocumentAsync(documentLink, options);
        }

        private async static Task Execute_spSetNorthAmerica3(DocumentClient client, StringBuilder sb)
        {
            sb.AppendLine();
            sb.AppendLine("Execute spSetNorthAmerica (no country)");

            // Should fail with no country and enforceSchema = true
            try
            {
                dynamic documentDefinition = new
                {
                    name = "James Smith",
                    address = new
                    {
                        postalCode = "12345"
                    }
                };
                var uri = UriFactory.CreateStoredProcedureUri("mydb", "mystore", "spSetNorthAmerica");
                var options = new RequestOptions { PartitionKey = new PartitionKey("12345") };
                var result = await client.ExecuteStoredProcedureAsync<object>(uri, options, documentDefinition, true);
            }
            catch (DocumentClientException ex)
            {
                sb.AppendLine($"Error: {ex.Message}");
            }
        }

        private async static Task Execute_spEnsureUniqueId(DocumentClient client, StringBuilder sb)
        {
            sb.AppendLine("Execute spEnsureUniqueId");

            dynamic documentDefinition1 = new { id = "DUPEJ", name = "James Dupe", address = new { postalCode = "12345" } };
            dynamic documentDefinition2 = new { id = "DUPEJ", name = "John Dupe", address = new { postalCode = "12345" } };
            dynamic documentDefinition3 = new { id = "DUPEJ", name = "Justin Dupe", address = new { postalCode = "12345" } };

            var uri = UriFactory.CreateStoredProcedureUri("mydb", "mystore", "spEnsureUniqueId");
            var options = new RequestOptions { PartitionKey = new PartitionKey("12345") };

            var result1 = await client.ExecuteStoredProcedureAsync<object>(uri, options, documentDefinition1);
            var document1 = result1.Response;
            sb.AppendLine($"New document ID: {document1.id}");

            var result2 = await client.ExecuteStoredProcedureAsync<object>(uri, options, documentDefinition2);
            var document2 = result2.Response;
            sb.AppendLine($"New document ID: {document2.id}");

            var result3 = await client.ExecuteStoredProcedureAsync<object>(uri, options, documentDefinition3);
            var document3 = result3.Response;
            sb.AppendLine($"New document ID: {document3.id}");

            // cleanup
            await client.DeleteDocumentAsync(document1._self.ToString(), options);
            await client.DeleteDocumentAsync(document2._self.ToString(), options);
            await client.DeleteDocumentAsync(document3._self.ToString(), options);
        }

        private async static Task Execute_spBulkInsert(DocumentClient client, StringBuilder sb)
        {
            sb.AppendLine("Execute spBulkInsert");
            sb.AppendLine();

            var docs = new List<dynamic>();
            var total = 5000;
            for (var i = 1; i <= total; i++)
            {
                dynamic doc = new
                {
                    name = $"Bulk inserted doc {i}",
                    address = new
                    {
                        postalCode = "12345"
                    }
                };
                docs.Add(doc);
            }

            var uri = UriFactory.CreateStoredProcedureUri("mydb", "mystore", "spBulkInsert");
            var options = new RequestOptions { PartitionKey = new PartitionKey("12345") };

            var started = DateTime.Now;
            var totalInserted = 0;
            while (totalInserted < total)
            {
                var callStarted = DateTime.Now;
                var result = await client.ExecuteStoredProcedureAsync<int>(uri, options, docs);
                var callElapsed = DateTime.Now.Subtract(callStarted);
                var inserted = result.Response;
                totalInserted += inserted;
                var remaining = total - totalInserted;
                sb.AppendLine($"Inserted {inserted} documents ({totalInserted} total, {remaining} remaining); elapsed: {callElapsed}");
                docs = docs.GetRange(inserted, docs.Count - inserted);
            }
            var elapsed = DateTime.Now.Subtract(started);
            sb.AppendLine();
            sb.AppendLine($"Overall elapsed: {elapsed}");
        }

        private async static Task Execute_spBulkDelete(DocumentClient client, StringBuilder sb)
        {
            sb.AppendLine("Execute spBulkDelete");
            sb.AppendLine();

            // query retrieves self-links for documents to bulk-delete
            var sql = "SELECT VALUE c._self FROM c WHERE STARTSWITH(c.name, 'Bulk inserted doc ') = true";
            var count = await Execute_spBulkDelete(client, sb, sql);
        }

        private async static Task<int> Execute_spBulkDelete(DocumentClient client, StringBuilder sb, string sql)
        {
            var uri = UriFactory.CreateStoredProcedureUri("mydb", "mystore", "spBulkDelete");
            var options = new RequestOptions { PartitionKey = new PartitionKey("12345") };

            var continuationFlag = true;
            var totalDeleted = 0;
            var started = DateTime.Now;
            while (continuationFlag)
            {
                var callStarted = DateTime.Now;
                var result = await client.ExecuteStoredProcedureAsync<BulkDeleteResponse>(uri, options, sql);
                var callElapsed = DateTime.Now.Subtract(callStarted);
                var response = result.Response;
                continuationFlag = response.ContinuationFlag;
                var deleted = response.Count;
                totalDeleted += deleted;
                sb.AppendLine($"Deleted {deleted} documents ({totalDeleted} total, more: {continuationFlag}); elapsed: {callElapsed}");
            }
            var elapsed = DateTime.Now.Subtract(started);
            sb.AppendLine();
            sb.AppendLine($"Overall elapsed: {elapsed}");

            return totalDeleted;
        }

        public static async Task<string> DeleteStoredProcedures(AppConfig config)
        {
            System.Diagnostics.Debugger.Break();

            var sb = new StringBuilder();

            sb.AppendLine(">>> Delete Stored Procedures <<<");
            sb.AppendLine();

            using (var client = new DocumentClient(new Uri(config.CosmosDbEndpoint), config.CosmosDbMasterKey))
            {
                await DeleteStoredProcedure(client, sb, "spHelloWorld");
                await DeleteStoredProcedure(client, sb, "spSetNorthAmerica");
                await DeleteStoredProcedure(client, sb, "spEnsureUniqueId");
                await DeleteStoredProcedure(client, sb, "spBulkInsert");
                await DeleteStoredProcedure(client, sb, "spBulkDelete");
            }

            return sb.ToString();
        }

        private async static Task DeleteStoredProcedure(DocumentClient client, StringBuilder sb, string sprocId)
        {
            var sprocUri = UriFactory.CreateStoredProcedureUri("mydb", "mystore", sprocId);

            await client.DeleteStoredProcedureAsync(sprocUri);

            sb.AppendLine($"Deleted stored procedure: {sprocId}");
        }

        #endregion

        #region "Triggers"

        public static IEnumerable<Trigger> GetTriggers(AppConfig config)
        {
            System.Diagnostics.Debugger.Break();

            var collectionUri = UriFactory.CreateDocumentCollectionUri("mydb", "mystore");

            using (var client = new DocumentClient(new Uri(config.CosmosDbEndpoint), config.CosmosDbMasterKey))
            {
                var triggers = client
                    .CreateTriggerQuery(collectionUri)
                    .ToList()
                    .OrderBy(t => t.Id);    // not directly supported on query; must follow .ToList

                return triggers;
            }
        }

        public static async Task<string> CreateTriggers(AppConfig config)
        {
            System.Diagnostics.Debugger.Break();

            var sb = new StringBuilder();

            sb.AppendLine(">>> Create Triggers <<<");
            sb.AppendLine();

            using (var client = new DocumentClient(new Uri(config.CosmosDbEndpoint), config.CosmosDbMasterKey))
            {
                var trgValidateDocument = File.ReadAllText(@".\Server\trgValidateDocument.js");
                await CreateTrigger(client, sb, "trgValidateDocument", trgValidateDocument, TriggerType.Pre, TriggerOperation.All);

                // Create post-trigger
                var trgUpdateMetadata = File.ReadAllText(@".\Server\trgUpdateMetadata.js");
                await CreateTrigger(client, sb, "trgUpdateMetadata", trgUpdateMetadata, TriggerType.Post, TriggerOperation.Create);
            }

            return sb.ToString();
        }

        private async static Task<Trigger> CreateTrigger(
            DocumentClient client,
            StringBuilder sb,
            string triggerId,
            string triggerBody,
            TriggerType triggerType,
            TriggerOperation triggerOperation)
        {
            var triggerDefinition = new Trigger
            {
                Id = triggerId,
                Body = triggerBody,
                TriggerType = triggerType,
                TriggerOperation = triggerOperation
            };

            var collectionUri = UriFactory.CreateDocumentCollectionUri("mydb", "mystore");

            var result = await client.CreateTriggerAsync(collectionUri, triggerDefinition);
            var trigger = result.Resource;
            sb.AppendLine($" Created trigger {trigger.Id}; RID: {trigger.ResourceId}");

            return trigger;
        }

        public static async Task<string> ExecuteTrigger(AppConfig config, string triggerId)
        {
            System.Diagnostics.Debugger.Break();

            var sb = new StringBuilder();

            sb.AppendLine($">>> Execute Trigger {triggerId} <<<");
            sb.AppendLine();

            using (var client = new DocumentClient(new Uri(config.CosmosDbEndpoint), config.CosmosDbMasterKey))
            {
                switch (triggerId)
                {
                    case "trgValidateDocument":
                        await Execute_trgValidateDocument(client, sb);
                        break;

                    case "trgUpdateMetadata":
                        await Execute_trgUpdateMetadata(client, sb);
                        break;
                }
            }

            return sb.ToString();
        }

        private static async Task Execute_trgValidateDocument(DocumentClient client, StringBuilder sb)
        {
            // Create three documents
            var doc1Link = await CreateDocumentWithValidation(client, sb, "mon");       // Monday
            var doc2Link = await CreateDocumentWithValidation(client, sb, "THURS");     // Thursday
            var doc3Link = await CreateDocumentWithValidation(client, sb, "sonday");    // error - won't get created

            // Update one of them
            await UpdateDocumentWithValidation(client, sb, doc2Link, "FRI");            // Thursday > Friday

            // Delete them
            var requestOptions = new RequestOptions { PartitionKey = new PartitionKey("12345") };
            await client.DeleteDocumentAsync(doc1Link, requestOptions);
            await client.DeleteDocumentAsync(doc2Link, requestOptions);
        }

        private async static Task<string> CreateDocumentWithValidation(DocumentClient client, StringBuilder sb, string weekdayOff)
        {
            var collectionUri = UriFactory.CreateDocumentCollectionUri("mydb", "mystore");

            dynamic documentDefinition = new
            {
                name = "John Doe",
                address = new { postalCode = "12345" },
                weekdayOff
            };

            var options = new RequestOptions { PreTriggerInclude = new[] { "trgValidateDocument" } };

            try
            {
                var result = await client.CreateDocumentAsync(collectionUri, documentDefinition, options);
                var document = result.Resource;

                sb.AppendLine(" Result:");
                sb.AppendLine($"  Id = {document.id}");
                sb.AppendLine($"  Weekday off = {document.weekdayOff}");
                sb.AppendLine($"  Weekday # off = {document.weekdayNumberOff}");
                sb.AppendLine();

                return document._self;
            }
            catch (DocumentClientException ex)
            {
                sb.AppendLine($"Error: {ex.Message}");
                sb.AppendLine();

                return null;
            }
        }

        private async static Task UpdateDocumentWithValidation(DocumentClient client, StringBuilder sb, string documentLink, string weekdayOff)
        {
            var collectionUri = UriFactory.CreateDocumentCollectionUri("mydb", "mystore");

            var sql = $"SELECT * FROM c WHERE c._self = '{documentLink}'";
            var feedOptions = new FeedOptions { EnableCrossPartitionQuery = true };
            var document = client.CreateDocumentQuery(collectionUri, sql, feedOptions).AsEnumerable().FirstOrDefault();

            document.weekdayOff = weekdayOff;

            var options = new RequestOptions { PreTriggerInclude = new[] { "trgValidateDocument" } };
            var result = await client.ReplaceDocumentAsync(document._self, document, options);
            document = result.Resource;

            sb.AppendLine(" Result:");
            sb.AppendLine($"  Id = {document.id}");
            sb.AppendLine($"  Weekday off = {document.weekdayOff}");
            sb.AppendLine($"  Weekday # off = {document.weekdayNumberOff}");
            sb.AppendLine();
        }

        private async static Task Execute_trgUpdateMetadata(DocumentClient client, StringBuilder sb)
        {
            // Show no metadata documents
            ViewMetaDocs(client, sb);

            // Create a bunch of documents across two partition keys
            var docs = new List<dynamic>
            {
				// 11229
				new { id = "11229a", address = new { postalCode = "11229" }, name = "New Customer ABCD" },
                new { id = "11229b", address = new { postalCode = "11229" }, name = "New Customer ABC" },
                new { id = "11229c", address = new { postalCode = "11229" }, name = "New Customer AB" },			// smallest
				new { id = "11229d", address = new { postalCode = "11229" }, name = "New Customer ABCDEF" },
                new { id = "11229e", address = new { postalCode = "11229" }, name = "New Customer ABCDEFG" },		// largest
				new { id = "11229f", address = new { postalCode = "11229" }, name = "New Customer ABCDE" },
				// 11235
				new { id = "11235a", address = new { postalCode = "11235" }, name = "New Customer AB" },
                new { id = "11235b", address = new { postalCode = "11235" }, name = "New Customer ABCDEFGHIJKL" },	// largest
				new { id = "11235c", address = new { postalCode = "11235" }, name = "New Customer ABC" },
                new { id = "11235d", address = new { postalCode = "11235" }, name = "New Customer A" },				// smallest
				new { id = "11235e", address = new { postalCode = "11235" }, name = "New Customer ABC" },
                new { id = "11235f", address = new { postalCode = "11235" }, name = "New Customer ABCDE" },
            };

            var collectionUri = UriFactory.CreateDocumentCollectionUri("mydb", "mystore");
            var options = new RequestOptions { PostTriggerInclude = new[] { "trgUpdateMetadata" } };
            foreach (var doc in docs)
            {
                await client.CreateDocumentAsync(collectionUri, doc, options);
            }

            // Show two metadata documents
            ViewMetaDocs(client, sb);

            // Cleanup
            var sql = @"
				SELECT c._self, c.address.postalCode
				FROM c
				WHERE c.address.postalCode IN('11229', '11235')
			";

            var feedOptions = new FeedOptions { EnableCrossPartitionQuery = true };
            var documentKeys = client.CreateDocumentQuery(collectionUri, sql, feedOptions).ToList();
            foreach (var documentKey in documentKeys)
            {
                var requestOptions = new RequestOptions { PartitionKey = new PartitionKey(documentKey.postalCode) };
                await client.DeleteDocumentAsync(documentKey._self, requestOptions);
            }
        }

        private static void ViewMetaDocs(DocumentClient client, StringBuilder sb)
        {
            var collectionUri = UriFactory.CreateDocumentCollectionUri("mydb", "mystore");
            var sql = @"SELECT * FROM c WHERE c.isMetaDoc";
            var feedOptions = new FeedOptions { EnableCrossPartitionQuery = true };
            var metaDocs = client.CreateDocumentQuery(collectionUri, sql, feedOptions).ToList();

            sb.AppendLine();
            sb.AppendLine($" Found {metaDocs.Count} metadata documents:");
            foreach (var metaDoc in metaDocs)
            {
                sb.AppendLine();
                sb.AppendLine($"  MetaDoc ID: {metaDoc.id}");
                sb.AppendLine($"  Metadata for: {metaDoc.address.postalCode}");
                sb.AppendLine($"  Smallest doc size: {metaDoc.minSize} ({metaDoc.minSizeId})");
                sb.AppendLine($"  Largest doc size: {metaDoc.maxSize} ({metaDoc.maxSizeId})");
                sb.AppendLine($"  Total doc size: {metaDoc.totalSize}");
            }
        }

        public static async Task<string> DeleteTriggers(AppConfig config)
        {
            System.Diagnostics.Debugger.Break();

            var sb = new StringBuilder();

            sb.AppendLine(">>> Delete Triggers <<<");
            sb.AppendLine();

            using (var client = new DocumentClient(new Uri(config.CosmosDbEndpoint), config.CosmosDbMasterKey))
            {
                await DeleteTrigger(client, sb, "trgValidateDocument");
                await DeleteTrigger(client, sb, "trgUpdateMetadata");
            }

            return sb.ToString();
        }

        private async static Task DeleteTrigger(DocumentClient client, StringBuilder sb, string triggerId)
        {
            var triggerUri = UriFactory.CreateTriggerUri("mydb", "mystore", triggerId);

            await client.DeleteTriggerAsync(triggerUri);

            sb.AppendLine($"Deleted trigger: {triggerId}");
        }

        #endregion

        #region "User-Defined Functions"

        public static IEnumerable<UserDefinedFunction> GetUserDefinedFunctions(AppConfig config)
        {
            System.Diagnostics.Debugger.Break();

            var collectionUri = UriFactory.CreateDocumentCollectionUri("mydb", "mystore");

            using (var client = new DocumentClient(new Uri(config.CosmosDbEndpoint), config.CosmosDbMasterKey))
            {
                var udfs = client
                    .CreateUserDefinedFunctionQuery(collectionUri)
                    .ToList()
                    .OrderBy(u => u.Id);    // not directly supported on query; must follow .ToList

                return udfs;
            }
        }

        public static async Task<string> CreateUserDefinedFunctions(AppConfig config)
        {
            System.Diagnostics.Debugger.Break();

            var sb = new StringBuilder();

            sb.AppendLine(">>> Create User Defined Functions <<<");
            sb.AppendLine();

            using (var client = new DocumentClient(new Uri(config.CosmosDbEndpoint), config.CosmosDbMasterKey))
            {
                await CreateUserDefinedFunction(client, sb, "udfRegEx");
                await CreateUserDefinedFunction(client, sb, "udfIsNorthAmerica");
                await CreateUserDefinedFunction(client, sb, "udfFormatCityStateZip");
            }

            return sb.ToString();
        }

        private async static Task<UserDefinedFunction> CreateUserDefinedFunction(DocumentClient client, StringBuilder sb, string udfId)
        {
            var udfBody = File.ReadAllText($@".\Server\{udfId}.js");
            var udfDefinition = new UserDefinedFunction
            {
                Id = udfId,
                Body = udfBody
            };

            var collectionUri = UriFactory.CreateDocumentCollectionUri("mydb", "mystore");

            var result = await client.CreateUserDefinedFunctionAsync(collectionUri, udfDefinition);
            var udf = result.Resource;
            sb.AppendLine($" Created user defined function {udf.Id}; RID: {udf.ResourceId}");

            return udf;
        }

        public static string ExecuteUserDefinedFunction(AppConfig config, string udfId)
        {
            System.Diagnostics.Debugger.Break();

            var sb = new StringBuilder();

            sb.AppendLine($">>> Execute UDF {udfId} <<<");
            sb.AppendLine();

            using (var client = new DocumentClient(new Uri(config.CosmosDbEndpoint), config.CosmosDbMasterKey))
            {
                switch (udfId)
                {
                    case "udfRegEx":
                        Execute_udfRegEx(client, sb);
                        break;

                    case "udfIsNorthAmerica":
                        Execute_udfIsNorthAmerica(client, sb);
                        break;

                    case "udfFormatCityStateZip":
                        Execute_udfFormatCityStateZip(client, sb);
                        break;
                }
            }

            return sb.ToString();
        }

        private static void Execute_udfRegEx(DocumentClient client, StringBuilder sb)
        {
            sb.AppendLine();
            sb.AppendLine("Querying for Rental customers");

            var sql = "SELECT c.id, c.name FROM c WHERE udf.udfRegEx(c.name, 'Rental') != null";

            var collectionUri = UriFactory.CreateDocumentCollectionUri("mydb", "mystore");
            var options = new FeedOptions { EnableCrossPartitionQuery = true };
            var documents = client.CreateDocumentQuery(collectionUri, sql, options).ToList();

            sb.AppendLine($"Found {documents.Count} Rental customers:");
            foreach (var document in documents)
            {
                sb.AppendLine($" {document.name} ({document.id})");
            }
        }

        private static void Execute_udfIsNorthAmerica(DocumentClient client, StringBuilder sb)
        {
            sb.AppendLine();
            sb.AppendLine("Querying for North American customers");

            var sql = @"
				SELECT c.name, c.address.countryRegionName
				FROM c
				WHERE udf.udfIsNorthAmerica(c.address.countryRegionName) = true";

            var collectionUri = UriFactory.CreateDocumentCollectionUri("mydb", "mystore");
            var options = new FeedOptions { EnableCrossPartitionQuery = true };
            var documents = client.CreateDocumentQuery(collectionUri, sql, options).ToList();

            sb.AppendLine($"Found {documents.Count} North American customers; first 20:");
            foreach (var document in documents.Take(20))
            {
                sb.AppendLine($" {document.name}, {document.countryRegionName}");
            }

            sql = @"
				SELECT c.name, c.address.countryRegionName
				FROM c
				WHERE udf.udfIsNorthAmerica(c.address.countryRegionName) = false";

            sb.AppendLine();
            sb.AppendLine("Querying for non North American customers");
            documents = client.CreateDocumentQuery(collectionUri, sql, options).ToList();

            sb.AppendLine($"Found {documents.Count} non North American customers; first 20:");
            foreach (var document in documents.Take(20))
            {
                sb.AppendLine($" {document.name}, {document.countryRegionName}");
            }
        }

        private static void Execute_udfFormatCityStateZip(DocumentClient client, StringBuilder sb)
        {
            sb.AppendLine();
            sb.AppendLine("Listing names with city, state, zip (first 20)");

            var sql = "SELECT c.name, udf.udfFormatCityStateZip(c) AS csz FROM c";
            var collectionUri = UriFactory.CreateDocumentCollectionUri("mydb", "mystore");
            var options = new FeedOptions { EnableCrossPartitionQuery = true };

            var documents = client.CreateDocumentQuery(collectionUri, sql, options).ToList();
            foreach (var document in documents.Take(20))
            {
                sb.AppendLine($" {document.name} located in {document.csz}");
            }
        }

        public static async Task<string> DeleteUserDefinedFunctions(AppConfig config)
        {
            System.Diagnostics.Debugger.Break();

            var sb = new StringBuilder();

            sb.AppendLine(">>> Delete Triggers <<<");
            sb.AppendLine();

            using (var client = new DocumentClient(new Uri(config.CosmosDbEndpoint), config.CosmosDbMasterKey))
            {
                await DeleteUserDefinedFunction(client, sb, "udfRegEx");
                await DeleteUserDefinedFunction(client, sb, "udfIsNorthAmerica");
                await DeleteUserDefinedFunction(client, sb, "udfFormatCityStateZip");
            }

            return sb.ToString();
        }

        private async static Task DeleteUserDefinedFunction(DocumentClient client, StringBuilder sb, string udfId)
        {
            var udfUri = UriFactory.CreateUserDefinedFunctionUri("mydb", "mystore", udfId);

            await client.DeleteUserDefinedFunctionAsync(udfUri);

            sb.AppendLine($"Deleted user defined function: {udfId}");
        }

        #endregion

    }
}
