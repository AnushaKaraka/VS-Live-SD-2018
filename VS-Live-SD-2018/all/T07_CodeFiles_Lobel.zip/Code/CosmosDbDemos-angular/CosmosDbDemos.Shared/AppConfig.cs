﻿namespace CosmosDbDemos.Shared
{
    public class AppConfig
    {
        public string CosmosDbEndpoint { get; set; }
        public string CosmosDbMasterKey { get; set; }
        public string CosmosDbGremlinHostName { get; set; }
        public string CosmosDbGremlinMasterKey { get; set; }
    }
}
