// modules
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { MatButtonModule } from '@angular/material';
import { MatDialogModule } from '@angular/material';
import { MatExpansionModule } from '@angular/material';
import { MatInputModule } from '@angular/material';
import { MatOptionModule } from '@angular/material';
import { MatProgressSpinnerModule } from '@angular/material';
import { MatSelectModule } from '@angular/material';
import { MatTableModule } from '@angular/material';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';

// components
import { AppComponent } from './app.component';
import { CassandraApiMenuComponent } from './cassandraApi/views/cassandraApiMenu/cassandraApiMenu.component';
import { HomeMenuComponent } from './home/views/homeMenu/homeMenu.component';
import { GremlinApiMenuComponent } from './gremlinApi/views/gremlinApiMenu/gremlinApiMenu.component';
import { MessageBoxComponent } from './shared/directives/messageBox/messageBox.component';
import { SqlApiCollectionsComponent } from './sqlApi/views/sqlApiCollections/sqlApiCollections.component';
import { SqlApiDatabasesComponent } from './sqlApi/views/sqlApiDatabases/sqlApiDatabases.component';
import { SqlApiDocumentsComponent } from './sqlApi/views/sqlApiDocuments/sqlApiDocuments.component';
import { SqlApiIndexingComponent } from './sqlApi/views/sqlApiIndexing/sqlApiIndexing.component';
import { SqlApiMenuComponent } from './sqlApi/views/sqlApiMenu/sqlApiMenu.component';
import { SqlApiSampleDataComponent } from './sqlApi/views/sqlApiSampleData/sqlApiSampleData.component';
import { SqlApiSecurityComponent } from './sqlApi/views/sqlApiSecurity/sqlApiSecurity.component';
import { SqlApiServerComponent } from './sqlApi/views/sqlApiServer/sqlApiServer.component';
import { TableApiMenuComponent } from './tableApi/views/tableApiMenu/tableApiMenu.component';

// services & pipes
import { FormatterService } from './shared/services/formatter.service';
import { JsonPipe } from '@angular/common';
import { WebApiService } from './shared/services/webapi.service';

// routes
const routes: Routes = [
	{ path: '', redirectTo: '/homeMenu', pathMatch: 'full' },
	{ path: 'homeMenu', component: HomeMenuComponent },
	{ path: 'sqlApiMenu', component: SqlApiMenuComponent },
	{ path: 'sqlApiSampleData', component: SqlApiSampleDataComponent },
	{ path: 'sqlApiDatabases', component: SqlApiDatabasesComponent },
	{ path: 'sqlApiCollections', component: SqlApiCollectionsComponent },
	{ path: 'sqlApiDocuments', component: SqlApiDocumentsComponent },
	{ path: 'sqlApiIndexing', component: SqlApiIndexingComponent },
	{ path: 'sqlApiSecurity', component: SqlApiSecurityComponent },
	{ path: 'sqlApiServer', component: SqlApiServerComponent },
	{ path: 'gremlinApiMenu', component: GremlinApiMenuComponent },
	{ path: 'tableApiMenu', component: TableApiMenuComponent },
	{ path: 'cassandraApiMenu', component: CassandraApiMenuComponent },
];

@NgModule({
	// modules
	imports: [
		BrowserAnimationsModule,
		BrowserModule,
		FormsModule,
		HttpClientModule,
		MatButtonModule,
		MatDialogModule,
		MatExpansionModule,
		MatInputModule,
		MatOptionModule,
		MatProgressSpinnerModule,
		MatSelectModule,
		MatTableModule,
		ReactiveFormsModule,
		RouterModule.forRoot(routes),
	],
	// components
	declarations: [
		AppComponent,
		HomeMenuComponent,
		GremlinApiMenuComponent,
		MessageBoxComponent,
		SqlApiCollectionsComponent,
		SqlApiDatabasesComponent,
		SqlApiDocumentsComponent,
		SqlApiIndexingComponent,
		SqlApiMenuComponent,
		SqlApiSampleDataComponent,
		SqlApiSecurityComponent,
		SqlApiServerComponent,
		TableApiMenuComponent,
		CassandraApiMenuComponent,
	],
	// services
	providers: [
		FormatterService,
		JsonPipe,
		WebApiService,
	],
	bootstrap: [AppComponent]
})
export class AppModule { }
