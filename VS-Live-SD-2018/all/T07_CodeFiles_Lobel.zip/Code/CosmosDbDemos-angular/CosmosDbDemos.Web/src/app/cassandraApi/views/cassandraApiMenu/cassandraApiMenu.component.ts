import { Component } from '@angular/core';
import { WebApiService } from 'src/app/shared/services/webapi.service';

@Component({
	templateUrl: './cassandraApiMenu.component.html',
	styleUrls: ['../../../app.component.css']
})
export class CassandraApiMenuComponent {

	constructor(
		private webapi: WebApiService,
	) {
	}

}
