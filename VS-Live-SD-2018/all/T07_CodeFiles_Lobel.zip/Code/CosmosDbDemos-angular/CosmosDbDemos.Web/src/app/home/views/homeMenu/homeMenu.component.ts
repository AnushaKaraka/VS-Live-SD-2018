import { Component } from '@angular/core';

@Component({
	templateUrl: './homeMenu.component.html',
	styleUrls: ['../../../app.component.css']
})
export class HomeMenuComponent {
}
