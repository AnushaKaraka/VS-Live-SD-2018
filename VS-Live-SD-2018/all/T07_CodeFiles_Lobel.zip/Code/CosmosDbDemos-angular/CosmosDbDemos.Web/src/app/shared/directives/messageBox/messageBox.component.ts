import { Component, ViewChild, TemplateRef } from '@angular/core'
import { MatDialog, MatDialogRef } from '@angular/material';

@Component({
	selector: 'message-box',
	templateUrl: './messageBox.component.html',
	styleUrls: ['../../../app.component.css'],
})
export class MessageBoxComponent {

	@ViewChild('messageBoxDialog') private messageBoxDialog: TemplateRef<any>;
	@ViewChild('webApiErrorDialog') private webApiErrorDialog: TemplateRef<any>;
	@ViewChild('confirmationDialog') private confirmationDialog: TemplateRef<any>;
	private dialogRef: MatDialogRef<any, any>;

	// Generic message
	private headerText: string;
	private bodyText: string;

	// Web API error
	private webApiErrorUrl: string;
	private webApiErrorDetails: any[];

	// Confirmation dialog
	private confirmationModalMessageText: string;
	private confirmationModalButtonText: string;
	private confirmationModalAction: any;

	constructor(
		private dialog: MatDialog,
	) {
	}

	// *** Generic message ***

	public Show(headerText: string, bodyText: string) {
		this.headerText = headerText;
		this.bodyText = bodyText;
		this.dialogRef = this.dialog.open(this.messageBoxDialog);
	}

	// *** Web API error ***

	public ShowWebApiError(error: any) {
		if (error.url) {
			this.webApiErrorUrl = error.url.split('?')[0];
			let details = error.error;
			if (typeof details == 'string') {
				details = JSON.parse(details);
			}
			this.webApiErrorDetails = details;
		}
		else {
			this.webApiErrorUrl = "Unknown URL";
			this.webApiErrorDetails = [
				{
					type: "HTTP Error",
					message: "Ensure that the Web API is running and try again"
				}
			];
		}

		this.dialogRef = this.dialog.open(this.webApiErrorDialog);
	}

	// *** Confirmation dialog ***

	public ShowConfirmationModal(messageText: string, buttonText: string, action: any) {
		this.confirmationModalMessageText = messageText;
		this.confirmationModalButtonText = buttonText;
		this.confirmationModalAction = function () {
			action();
			this.dialogRef.close();
		}
		this.dialogRef = this.dialog.open(this.confirmationDialog);
	}

	private ConfirmAction() {
		this.confirmationModalAction();
	}

}
