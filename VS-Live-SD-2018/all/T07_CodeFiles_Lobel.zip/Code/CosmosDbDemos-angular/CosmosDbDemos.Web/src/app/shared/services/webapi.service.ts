import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class WebApiService {

	constructor(
		private http: HttpClient,
	) {
	}

	public InvokeGet(url: string, callback: any) {
		url = this.GetWebApiHostName() + url;
		this.http
			.get(url)
			.subscribe(
			data => callback({ isError: false, data: data }),
			error => callback({ isError: true, error: error }),
		);
	}

	public InvokeGetText(url: string, callback: any) {
		url = this.GetWebApiHostName() + url;
		this.http
			.get(url, { responseType: 'text'})
			.subscribe(
			data => callback({ isError: false, data: data }),
			error => callback({ isError: true, error: error }),
		);
	}

	public InvokePost(url: string, data: any, callback: any) {
		url = this.GetWebApiHostName() + url;
		this.http
			.post(url, data)
			.subscribe(
			data => callback({ isError: false, data: data }),
			error => callback({ isError: true, error: error }),
		);
	}

	public InvokeDelete(url: string, callback: any) {
		url = this.GetWebApiHostName() + url;
		this.http
			.delete(url)
			.subscribe(
			data => callback({ isError: false, data: data }),
			error => callback({ isError: true, error: error }),
		);
	}

	private GetWebApiHostName() {
		return "http://localhost:64630";
	}

}
