import { Component, ViewChild, OnInit, TemplateRef } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { WebApiService } from 'src/app/shared/services/webapi.service';
import { MatDialog, MatDialogRef } from '@angular/material';
import { MessageBoxComponent } from 'src/app/shared/directives/messageBox/messageBox.component';

@Component({
	templateUrl: './sqlApiCollections.component.html',
	styleUrls: [
		'../../../app.component.css',
	]
})
export class SqlApiCollectionsComponent implements OnInit {

	@ViewChild('alertMessage') private alertMessage: MessageBoxComponent;
	@ViewChild('createCollectionDialog') private createCollectionDialog: TemplateRef<any>;
	@ViewChild('deleteCollectionDialog') private deleteCollectionDialog: TemplateRef<any>;
	private busyIndex: number = 0;
	private databaseSelectionForm: FormGroup;
	private databases;
	private dialogRef: MatDialogRef<any, any>;
	private form: FormGroup;
	private gridColumns;
	private gridData;

	constructor(
		private dialog: MatDialog,
		private formBuilder: FormBuilder,
		private webapi: WebApiService,
	) {
	}

	public ngOnInit() {
		this.databaseSelectionForm = this.formBuilder.group({
			DatabaseId: [],
		});
		this.GetDatabases();
	}

	private GetDatabases() {
		this.StartBusy();
		this.webapi.InvokeGet('/api/sql/databases', (result) => {
			this.EndBusy();
			if (result.isError) {
				this.alertMessage.ShowWebApiError(result.error);
				return;
			}
			this.databases = result.data;
		});
	}

	private ViewCollections() {
		let id = this.databaseSelectionForm.value.DatabaseId;
		this.StartBusy();
		this.webapi.InvokeGet(`/api/sql/collections/${id}`, (result) => {
			this.EndBusy();
			if (result.isError) {
				this.alertMessage.ShowWebApiError(result.error);
				return;
			}
			this.gridColumns = ['CollectionId', 'ResourceId', 'SelfLink', 'PartitionKey', 'Throughput', 'Delete'];
			this.gridData = result.data;
		});

	}

	private PromptCreateCollection() {
		this.form = this.formBuilder.group({
			DatabaseId: [this.databaseSelectionForm.value.DatabaseId],
			CollectionId: [],
			PartitionKey: [],
			Throughput: [10000]
		});
		this.dialogRef = this.dialog.open(this.createCollectionDialog);
	}

	private CreateCollection() {
		this.StartBusy();
		this.webapi.InvokePost(`/api/sql/collections`, this.form.value, (result) => {
			this.EndBusy();
			if (result.isError) {
				this.alertMessage.ShowWebApiError(result.error);
				return;
			}
			this.dialogRef.close();
			this.ViewCollections();
		});
	}

	private PromptDeleteCollection(id: string) {
		this.form = this.formBuilder.group({
			CollectionId: [id],
		});
		this.dialogRef = this.dialog.open(this.deleteCollectionDialog);
	}

	private DeleteCollection() {
		let did: string = this.databaseSelectionForm.value.DatabaseId;
		let cid: string = this.form.value.CollectionId;
		this.StartBusy();
		this.webapi.InvokeDelete(`/api/sql/collections/${did}/${cid}`, (result) => {
			this.EndBusy();
			if (result.isError) {
				this.alertMessage.ShowWebApiError(result.error);
				return;
			}
			this.dialogRef.close();
			this.ViewCollections();
		});
	}

	private StartBusy() {
		this.gridColumns = null;
		this.gridData = null;
		this.busyIndex++;
	}

	private EndBusy() {
		this.busyIndex--;
	}

}
