import { Component, ViewChild, OnInit, TemplateRef } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { WebApiService } from 'src/app/shared/services/webapi.service';
import { MatDialog, MatDialogRef } from '@angular/material';
import { MessageBoxComponent } from 'src/app/shared/directives/messageBox/messageBox.component';

@Component({
	templateUrl: './sqlApiDatabases.component.html',
	styleUrls: [
		'../../../app.component.css',
	]
})
export class SqlApiDatabasesComponent implements OnInit {

	@ViewChild('alertMessage') private alertMessage: MessageBoxComponent;
	@ViewChild('createDatabaseDialog') private createDatabaseDialog: TemplateRef<any>;
	@ViewChild('deleteDatabaseDialog') private deleteDatabaseDialog: TemplateRef<any>;
	private busyIndex: number = 0;
	private dialogRef: MatDialogRef<any, any>;
	private form: FormGroup;
	private gridColumns: any[];
	private gridData: any[];

	constructor(
		private dialog: MatDialog,
		private formBuilder: FormBuilder,
		private webapi: WebApiService,
	) {
	}

	public ngOnInit() {
	}	

	private ViewDatabases() {
		this.StartBusy();
		this.webapi.InvokeGet('/api/sql/databases', (result) => {
			this.EndBusy();
			if (result.isError) {
				this.alertMessage.ShowWebApiError(result.error);
				return;
			}
			this.gridColumns = ['DatabaseId', 'ResourceId', 'SelfLink', 'Delete'];
			this.gridData = result.data;
		});
	}

	private PromptCreateDatabase() {
		this.form = this.formBuilder.group({
			DatabaseId: [],
		});
		this.dialogRef = this.dialog.open(this.createDatabaseDialog);
	}

	private CreateDatabase() {
		this.StartBusy();
		this.webapi.InvokePost('/api/sql/databases', this.form.value, (result) => {
			this.EndBusy();
			if (result.isError) {
				this.alertMessage.ShowWebApiError(result.error);
				return;
			}
			this.dialogRef.close();
			this.ViewDatabases();
		});
	}

	private PromptDeleteDatabase(id: string) {
		this.form = this.formBuilder.group({
			DatabaseId: [id],
		});
		this.dialogRef = this.dialog.open(this.deleteDatabaseDialog);
	}

	private DeleteDatabase() {
		let id: string = this.form.value.DatabaseId;
		this.StartBusy();
		this.webapi.InvokeDelete(`/api/sql/databases/${id}`, (result) => {
			this.EndBusy();
			if (result.isError) {
				this.alertMessage.ShowWebApiError(result.error);
				return;
			}
			if (this.dialogRef) {
				this.dialogRef.close();
			}
			this.ViewDatabases();
		});
	}

	private StartBusy() {
		this.gridColumns = null;
		this.gridData = null;
		this.busyIndex++;
	}

	private EndBusy() {
		this.busyIndex--;
	}

}
