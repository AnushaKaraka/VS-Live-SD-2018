import { Component, ViewChild, OnInit, TemplateRef } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { WebApiService } from 'src/app/shared/services/webapi.service';
import { FormatterService } from 'src/app/shared/services/formatter.service';
import { MatDialog, MatDialogRef } from '@angular/material';
import { MessageBoxComponent } from 'src/app/shared/directives/messageBox/messageBox.component';

@Component({
	templateUrl: './sqlApiDocuments.component.html',
	styleUrls: [
		'./sqlApiDocuments.component.css',
		'../../../app.component.css',
	]
})
export class SqlApiDocumentsComponent implements OnInit {

	@ViewChild('alertMessage') private alertMessage: MessageBoxComponent;
	private busyIndex: number = 0;
	private collectionSelectionForm: FormGroup;
	private databases: any[];
	private collections: any[];
	private document: any;
	private documents: any[];
	private documentColumns: any[];
	private continuationToken: any;

	constructor(
		private dialog: MatDialog,
		private formBuilder: FormBuilder,
		private webapi: WebApiService,
		private formatter: FormatterService,
	) {
	}

	public ngOnInit() {
		this.collectionSelectionForm = this.formBuilder.group({
			DatabaseId: [],
			CollectionId: [],
		});
		this.GetDatabases();
	}

	private GetDatabases() {
		this.StartBusy();
		this.webapi.InvokeGet('/api/sql/databases', (result) => {
			this.EndBusy();
			if (result.isError) {
				this.alertMessage.ShowWebApiError(result.error);
				return;
			}
			this.databases = result.data;
		});
	}

	private GetCollections() {
		let id = this.collectionSelectionForm.value.DatabaseId;
		this.StartBusy();
		this.webapi.InvokeGet(`/api/sql/collections/${id}`, (result) => {
			this.EndBusy();
			if (result.isError) {
				this.alertMessage.ShowWebApiError(result.error);
				return;
			}
			this.collections = result.data;
		});
	}

	private CreateDocument(demoType: string) {
		let did: string = this.collectionSelectionForm.value.DatabaseId;
		let cid: string = this.collectionSelectionForm.value.CollectionId;
		this.StartBusy();
		this.webapi.InvokeGet(`/api/sql/documents/create/${demoType}/${did}/${cid}`, (result) => {
			this.EndBusy();
			if (result.isError) {
				this.alertMessage.ShowWebApiError(result.error);
				return;
			}
			this.document = result.data;
		});
	}

	private QueryDocuments(demoType: string) {
		let did: string = this.collectionSelectionForm.value.DatabaseId;
		let cid: string = this.collectionSelectionForm.value.CollectionId;
		this.StartBusy();
		this.webapi.InvokeGet(`/api/sql/documents/query/${demoType}/${did}/${cid}`, (result) => {
			this.EndBusy();
			if (result.isError) {
				this.alertMessage.ShowWebApiError(result.error);
				return;
			}
			this.documentColumns = ['DocumentId', 'Name', 'City' ];
			this.documents = result.data;
		});
	}

	private QueryDocumentsFirstPage() {
		let did: string = this.collectionSelectionForm.value.DatabaseId;
		let cid: string = this.collectionSelectionForm.value.CollectionId;
		this.StartBusy();
		this.webapi.InvokeGet(`/api/sql/documents/queryFirstPage/${did}/${cid}`, (result) => {
			this.EndBusy();
			if (result.isError) {
				this.alertMessage.ShowWebApiError(result.error);
				return;
			}
			this.documentColumns = ['DocumentId', 'Name', 'City'];
			this.documents = result.data.data;
			this.document = JSON.parse(result.data.continuationToken);
			this.continuationToken = this.document;
		});
	}

	private QueryDocumentsNextPage() {
		let did: string = this.collectionSelectionForm.value.DatabaseId;
		let cid: string = this.collectionSelectionForm.value.CollectionId;
		this.busyIndex++;
		this.webapi.InvokePost(`/api/sql/documents/queryNextPage/${did}/${cid}`, this.continuationToken, (result) => {
			this.busyIndex--;
			if (result.isError) {
				this.alertMessage.ShowWebApiError(result.error);
				return;
			}
			this.documentColumns = ['DocumentId', 'Name', 'City'];
			this.documents = this.documents.concat(result.data.data);
			this.document = JSON.parse(result.data.continuationToken);
			this.continuationToken = this.document;
		});
	}

	private ReplaceDocuments() {
		let did: string = this.collectionSelectionForm.value.DatabaseId;
		let cid: string = this.collectionSelectionForm.value.CollectionId;
		this.StartBusy();
		this.webapi.InvokeGetText(`/api/sql/documents/replace/${did}/${cid}`, (result) => {
			this.EndBusy();
			if (result.isError) {
				this.alertMessage.ShowWebApiError(result.error);
				return;
			}
			this.document = result.data;
		});
	}

	private DeleteDocuments() {
		let did: string = this.collectionSelectionForm.value.DatabaseId;
		let cid: string = this.collectionSelectionForm.value.CollectionId;
		this.StartBusy();
		this.webapi.InvokeGetText(`/api/sql/documents/delete/${did}/${cid}`, (result) => {
			this.EndBusy();
			if (result.isError) {
				this.alertMessage.ShowWebApiError(result.error);
				return;
			}
			this.document = result.data;
		});
	}

	private StartBusy() {
		this.document = null;
		this.documents = null;
		this.busyIndex++;
	}

	private EndBusy() {
		this.busyIndex--;
	}

}
