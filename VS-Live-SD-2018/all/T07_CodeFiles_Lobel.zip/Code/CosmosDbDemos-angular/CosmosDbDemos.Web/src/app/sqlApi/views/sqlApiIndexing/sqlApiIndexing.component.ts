import { Component, ViewChild } from '@angular/core';
import { WebApiService } from 'src/app/shared/services/webapi.service';
import { FormatterService } from 'src/app/shared/services/formatter.service';
import { MessageBoxComponent } from 'src/app/shared/directives/messageBox/messageBox.component';

@Component({
	templateUrl: './sqlApiIndexing.component.html',
	styleUrls: [
		'./sqlApiIndexing.component.css',
		'../../../app.component.css',
	]
})
export class SqlApiIndexingComponent {

	@ViewChild('alertMessage') private alertMessage: MessageBoxComponent;
	private busyIndex: number = 0;
	private document;

	constructor(
		private formatter: FormatterService,
		private webapi: WebApiService,
	) {
	}

	private AutomaticIndexing() {
		this.CallServer('/api/sql/indexing/automatic');
	}

	private ManualIndexing() {
		this.CallServer('/api/sql/indexing/manual');
	}

	private PathIndexing() {
		this.CallServer('/api/sql/indexing/path');
	}

	private CallServer(url: string) {
		this.StartBusy();
		this.webapi.InvokeGetText(url, (result) => {
			this.EndBusy();
			if (result.isError) {
				this.alertMessage.ShowWebApiError(result.error);
				return;
			}
			this.document = result.data;
		});
	}

	private StartBusy() {
		this.document = null;
		this.busyIndex++;
	}

	private EndBusy() {
		this.busyIndex--;
	}

}
