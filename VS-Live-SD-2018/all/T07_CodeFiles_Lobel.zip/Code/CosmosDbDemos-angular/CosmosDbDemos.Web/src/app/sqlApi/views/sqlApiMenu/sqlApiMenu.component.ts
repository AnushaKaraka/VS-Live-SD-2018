import { Component, ViewChild } from '@angular/core';
import { WebApiService } from 'src/app/shared/services/webapi.service';
import { MessageBoxComponent } from 'src/app/shared/directives/messageBox/messageBox.component';

@Component({
	templateUrl: './sqlApiMenu.component.html',
	styleUrls: ['../../../app.component.css']
})
export class SqlApiMenuComponent {

	@ViewChild('alertMessage') private alertMessage: MessageBoxComponent;
	private busyIndex: number = 0;

	constructor(
		private webapi: WebApiService,
	) {
	}

	private CreateFamiliesCollection() {
		this.StartBusy();
		this.webapi.InvokeGetText('/api/sql/familiesCollection/create', (result) => {
			this.EndBusy();
			if (result.isError) {
				this.alertMessage.ShowWebApiError(result.error);
				return;
			}
			this.alertMessage.Show("Done", result.data);
		});
	}

	private StartBusy() {
		this.busyIndex++;
	}

	private EndBusy() {
		this.busyIndex--;
	}

}
