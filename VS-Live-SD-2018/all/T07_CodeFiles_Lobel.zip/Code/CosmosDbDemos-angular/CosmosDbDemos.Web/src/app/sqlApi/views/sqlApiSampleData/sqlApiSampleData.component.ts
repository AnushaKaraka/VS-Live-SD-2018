import { Component, ViewChild } from '@angular/core';
import { WebApiService } from 'src/app/shared/services/webapi.service';
import { MessageBoxComponent } from 'src/app/shared/directives/messageBox/messageBox.component';

@Component({
	templateUrl: './sqlApiSampleData.component.html',
	styleUrls: ['../../../app.component.css']
})
export class SqlApiSampleDataComponent {

	@ViewChild('alertMessage') private alertMessage: MessageBoxComponent;
	private busyIndex: number = 0;

	constructor(
		private webapi: WebApiService,
	) {
	}

	private CreateFamiliesCollection(demoType: string) {
		this.StartBusy();
		this.webapi.InvokeGetText(`/api/sql/familiesCollection/create/${demoType}`, (result) => {
			this.EndBusy();
			if (result.isError) {
				this.alertMessage.ShowWebApiError(result.error);
				return;
			}
			this.alertMessage.Show("Done", result.data);
		});
	}

	private StartBusy() {
		this.busyIndex++;
	}

	private EndBusy() {
		this.busyIndex--;
	}

}
