import { Component, ViewChild } from '@angular/core';
import { FormatterService } from 'src/app/shared/services/formatter.service';
import { WebApiService } from 'src/app/shared/services/webapi.service';
import { MessageBoxComponent } from 'src/app/shared/directives/messageBox/messageBox.component';

@Component({
	templateUrl: './sqlApiSecurity.component.html',
	styleUrls: [
		'./sqlApiSecurity.component.css',
		'../../../app.component.css',
	]
})
export class SqlApiSecurityComponent {

	@ViewChild('alertMessage') private alertMessage: MessageBoxComponent;
	private busyIndex: number = 0;
	private document: any;
	private documents: any[];
	private documentColumns: any[];
	private alicePerm: any;
	private tomPerm: any;

	constructor(
		private webapi: WebApiService,
		private formatter: FormatterService,
	) {
	}

	private ViewUsers() {
		this.StartBusy();
		this.webapi.InvokeGet('/api/sql/users', (result) => {
			this.EndBusy();
			if (result.isError) {
				this.alertMessage.ShowWebApiError(result.error);
				return;
			}
			this.documentColumns = ['UserId', 'ResourceId', 'SelfLink'];
			this.documents = result.data;
			this.document = null;
		});
	}

	private CreateUsers() {
		this.StartBusy();
		this.webapi.InvokeGetText('/api/sql/createUsers', (result) => {
			this.EndBusy();
			if (result.isError) {
				this.alertMessage.ShowWebApiError(result.error);
				return;
			}
			this.document = result.data;
		});
	}

	private CreatePermissions() {
		this.StartBusy();
		this.webapi.InvokeGet('/api/sql/createPermissions', (result) => {
			this.EndBusy();
			if (result.isError) {
				this.alertMessage.ShowWebApiError(result.error);
				return;
			}
			this.document = result.data.output;
			this.alicePerm = result.data.alicePerm;
			this.tomPerm = result.data.tomPerm;
		});
	}

	private ViewPermissions(username: string) {
		this.StartBusy();
		this.webapi.InvokeGet(`/api/sql/permissions/${username}`, (result) => {
			this.EndBusy();
			if (result.isError) {
				this.alertMessage.ShowWebApiError(result.error);
				return;
			}
			this.documentColumns = ['PermissionId', 'ResourceId', 'PermissionMode', 'Token'];
			this.documents = result.data;
		});
	}

	private TestPermissions(username: string) {
		this.StartBusy();
		this.webapi.InvokeGetText(`/api/sql/testPermissions/${username}`, (result) => {
			this.EndBusy();
			if (result.isError) {
				this.alertMessage.ShowWebApiError(result.error);
				return;
			}
			this.document = result.data;
		});
	}

	private DeleteUsers() {
		this.StartBusy();
		this.webapi.InvokeGetText('/api/sql/deleteUsers', (result) => {
			this.EndBusy();
			if (result.isError) {
				this.alertMessage.ShowWebApiError(result.error);
				return;
			}
			this.document = result.data;
		});
	}

	private StartBusy() {
		this.document = null;
		this.documents = null;
		this.busyIndex++;
	}

	private EndBusy() {
		this.busyIndex--;
	}

}
