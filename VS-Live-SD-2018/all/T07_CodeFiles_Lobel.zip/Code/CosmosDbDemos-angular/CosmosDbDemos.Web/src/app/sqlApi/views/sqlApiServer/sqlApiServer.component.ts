import { Component, ViewChild } from '@angular/core';
import { WebApiService } from 'src/app/shared/services/webapi.service';
import { FormatterService } from 'src/app/shared/services/formatter.service';
import { MessageBoxComponent } from 'src/app/shared/directives/messageBox/messageBox.component';

@Component({
	templateUrl: './sqlApiServer.component.html',
	styleUrls: [
		'./sqlApiServer.component.css',
		'../../../app.component.css',
	]
})
export class SqlApiServerComponent {

	@ViewChild('alertMessage') private alertMessage: MessageBoxComponent;
	private busyIndex: number = 0;
	private document: any;
	private documents: any[];
	private documentColumns: any[];

	constructor(
		private formatter: FormatterService,
		private webapi: WebApiService,
	) {
	}

	private CreateStoredProcedures() {
		this.StartBusy();
		this.webapi.InvokeGetText('/api/sql/createSprocs', (result) => {
			this.EndBusy();
			if (result.isError) {
				this.alertMessage.ShowWebApiError(result.error);
				return;
			}
			this.document = result.data;
		});
	}

	private ViewStoredProcedures() {
		this.StartBusy();
		this.webapi.InvokeGet('/api/sql/sprocs', (result) => {
			this.EndBusy();
			if (result.isError) {
				this.alertMessage.ShowWebApiError(result.error);
				return;
			}
			this.documentColumns = ['SprocId', 'SelfLink'];
			this.documents = result.data;
		});
	}

	private ExecuteStoredProcedure(sprocId: string) {
		this.StartBusy();
		this.webapi.InvokeGetText(`/api/sql/executeSproc/${sprocId}`, (result) => {
			this.EndBusy();
			if (result.isError) {
				this.alertMessage.ShowWebApiError(result.error);
				return;
			}
			this.document = result.data;
		});
	}

	private DeleteStoredProcedures() {
		this.StartBusy();
		this.webapi.InvokeGetText('/api/sql/deleteSprocs', (result) => {
			this.EndBusy();
			if (result.isError) {
				this.alertMessage.ShowWebApiError(result.error);
				return;
			}
			this.document = result.data;
		});
	}

	private CreateTriggers() {
		this.StartBusy();
		this.webapi.InvokeGetText('/api/sql/createTriggers', (result) => {
			this.EndBusy();
			if (result.isError) {
				this.alertMessage.ShowWebApiError(result.error);
				return;
			}
			this.document = result.data;
		});
	}

	private ViewTriggers() {
		this.StartBusy();
		this.webapi.InvokeGet('/api/sql/triggers', (result) => {
			this.EndBusy();
			if (result.isError) {
				this.alertMessage.ShowWebApiError(result.error);
				return;
			}
			this.documentColumns = ['TriggerId', 'SelfLink', 'Type', 'Operation'];
			this.documents = result.data;
		});
	}

	private ExecuteTrigger(triggerId: string) {
		this.StartBusy();
		this.webapi.InvokeGetText(`/api/sql/executeTrigger/${triggerId}`, (result) => {
			this.EndBusy();
			if (result.isError) {
				this.alertMessage.ShowWebApiError(result.error);
				return;
			}
			this.document = result.data;
		});
	}

	private DeleteTriggers() {
		this.StartBusy();
		this.webapi.InvokeGetText('/api/sql/deleteTriggers', (result) => {
			this.EndBusy();
			if (result.isError) {
				this.alertMessage.ShowWebApiError(result.error);
				return;
			}
			this.document = result.data;
		});
	}

	private CreateUserDefinedFunctions() {
		this.StartBusy();
		this.webapi.InvokeGetText('/api/sql/createUdfs', (result) => {
			this.EndBusy();
			if (result.isError) {
				this.alertMessage.ShowWebApiError(result.error);
				return;
			}
			this.document = result.data;
		});
	}

	private ViewUserDefinedFunctions() {
		this.StartBusy();
		this.webapi.InvokeGet('/api/sql/udfs', (result) => {
			this.EndBusy();
			if (result.isError) {
				this.alertMessage.ShowWebApiError(result.error);
				return;
			}
			this.documentColumns = ['UdfId', 'ResourceId', 'SelfLink'];
			this.documents = result.data;
		});
	}

	private ExecuteUserDefinedFunction(udfId: string) {
		this.StartBusy();
		this.webapi.InvokeGetText(`/api/sql/executeUdf/${udfId}`, (result) => {
			this.EndBusy();
			if (result.isError) {
				this.alertMessage.ShowWebApiError(result.error);
				return;
			}
			this.document = result.data;
		});
	}

	private DeleteUserDefinedFunctions() {
		this.StartBusy();
		this.webapi.InvokeGetText('/api/sql/deleteUdfs', (result) => {
			this.EndBusy();
			if (result.isError) {
				this.alertMessage.ShowWebApiError(result.error);
				return;
			}
			this.document = result.data;
		});
	}

	private StartBusy() {
		this.document = null;
		this.documents = null;
		this.busyIndex++;
	}

	private EndBusy() {
		this.busyIndex--;
	}

}
