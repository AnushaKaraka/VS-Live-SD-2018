import { Component } from '@angular/core';
import { WebApiService } from 'src/app/shared/services/webapi.service';

@Component({
	templateUrl: './tableApiMenu.component.html',
	styleUrls: ['../../../app.component.css']
})
export class TableApiMenuComponent {

	constructor(
		private webapi: WebApiService,
	) {
	}

}
