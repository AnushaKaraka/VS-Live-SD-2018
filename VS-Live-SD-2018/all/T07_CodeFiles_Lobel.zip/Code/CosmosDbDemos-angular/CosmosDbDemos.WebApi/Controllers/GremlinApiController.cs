﻿using CosmosDbDemos.DataLayer;
using CosmosDbDemos.Shared;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System.Threading.Tasks;

namespace CosmosDbDemos.WebApi.Controllers
{
    public class GremlinApiController
    {
        private AppConfig _config;

        public GremlinApiController(IOptions<AppConfig> config)
        {
            this._config = config.Value;
        }

        [HttpGet]
        [Route("api/gremlin/airport/populate")]
        public async Task<string> CreateAirportGraph()
        {
            var response = await GremlinApiGraphRepo.PopulateAirportGraph(this._config);
            return response;
        }

        [HttpGet]
        [Route("api/gremlin/airport/query")]
        public async Task<string> QueryAirportGraph()
        {
            var response = await GremlinApiGraphRepo.QueryAirportGraph(this._config);
            return response;
        }

    }

}
