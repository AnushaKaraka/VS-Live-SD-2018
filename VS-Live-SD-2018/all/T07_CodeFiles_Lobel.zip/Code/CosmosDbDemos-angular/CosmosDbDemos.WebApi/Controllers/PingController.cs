﻿using Microsoft.AspNetCore.Mvc;
using System;

namespace CosmosDbDemos.WebApi.Controllers
{
    public class PingController
    {
        [Route("api/ping")]
        public string Ping()
        {
            return $"Cosmos DB Demos Web API controller running at {DateTime.Now}";
        }
    }

}
