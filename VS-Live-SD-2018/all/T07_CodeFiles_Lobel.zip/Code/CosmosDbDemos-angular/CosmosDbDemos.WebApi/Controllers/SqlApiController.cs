﻿using CosmosDbDemos.DataLayer;
using CosmosDbDemos.Shared;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CosmosDbDemos.WebApi.Controllers
{
    public class SqlApiController
    {
        private AppConfig _config;

        public SqlApiController(IOptions<AppConfig> config)
        {
            this._config = config.Value;
        }

        #region "Create Families Collection"

        [HttpGet]
        [Route("api/sql/familiesCollection/create/queryDemos")]
        public async Task<string> CreateFamiliesCollectionForQueryDemos()
        {
            var message = await SqlApiFamiliesRepo.CreateFamiliesCollectionForQueryDemos(this._config);

            return message;
        }

        [HttpGet]
        [Route("api/sql/familiesCollection/create/globalDistDemos")]
        public async Task<string> CreateFamiliesCollectionForGlobalDistDemos(string demoType)
        {
            var message = await SqlApiFamiliesRepo.CreateFamiliesCollectionForGlobalDistDemos(this._config);

            return message;
        }

        #endregion

        #region "Databases"

        [HttpGet]
        [Route("api/sql/databases")]
        public IEnumerable<object> GetDatabases()
        {
            var response = SqlApiDatabasesRepo.GetDatabases(this._config);
            return response;
        }

        [HttpPost]
        [Route("api/sql/databases")]
        public async Task<object> CreateDatabase([FromBody] CreateDatabaseRequest request)
        {
            var response = await SqlApiDatabasesRepo.CreateDatabase(this._config, request.DatabaseId);
            return response;
        }

        [HttpDelete]
        [Route("api/sql/databases/{databaseId}")]
        public async Task DeleteDatabase(string databaseId)
        {
            await SqlApiDatabasesRepo.DeleteDatabase(this._config, databaseId);
        }

        #endregion

        #region "Collections"

        [HttpGet]
        [Route("api/sql/collections/{databaseId}")]
        public IEnumerable<object> GetCollections(string databaseId)
        {
            var response = SqlApiCollectionsRepo.GetCollections(this._config, databaseId);
            return response;
        }

        [HttpPost]
        [Route("api/sql/collections")]
        public async Task<object> CreateCollection([FromBody] CreateCollectionRequest request)
        {
            var response = await SqlApiCollectionsRepo.CreateCollection(this._config, request.DatabaseId, request.CollectionId, request.PartitionKey, request.Throughput);
            return response;
        }

        [HttpDelete]
        [Route("api/sql/collections/{databaseId}/{collectionId}")]
        public async Task DeleteCollection(string databaseId, string collectionId)
        {
            await SqlApiCollectionsRepo.DeleteCollection(this._config, databaseId, collectionId);
        }

        #endregion

        #region "Documents"

        [HttpGet]
        [Route("api/sql/documents/create/{demoType}/{databaseId}/{collectionId}")]
        public object CreateDocument(string demoType, string databaseId, string collectionId)
        {
            var task = default(Task<object>);

            switch (demoType)
            {
                case "dynamic":
                    task = SqlApiDocumentsRepo.CreateDocumentFromDynamic(this._config, databaseId, collectionId);
                    break;

                case "json":
                    task = SqlApiDocumentsRepo.CreateDocumentFromJson(this._config, databaseId, collectionId);
                    break;

                case "poco":
                    task = SqlApiDocumentsRepo.CreateDocumentFromPoco(this._config, databaseId, collectionId);
                    break;

                default:
                    throw new Exception($"Unsupported demo type: {demoType}");
            }
            task.Wait();

            return task.Result;
        }

        [HttpGet]
        [Route("api/sql/documents/query/{demoType}/{databaseId}/{collectionId}")]
        public IEnumerable<object> QueryDocuments(string demoType, string databaseId, string collectionId)
        {
            var documents = default(IEnumerable<object>);

            switch (demoType)
            {
                case "dynamic":
                    documents = SqlApiDocumentsRepo.QueryForDynamic(this._config, databaseId, collectionId);
                    break;

                case "poco":
                    documents = SqlApiDocumentsRepo.QueryForPoco(this._config, databaseId, collectionId);
                    break;

                case "linq":
                    documents = SqlApiDocumentsRepo.QueryWithLinq(this._config, databaseId, collectionId);
                    break;
            }

            return documents;
        }

        [HttpGet]
        [Route("api/sql/documents/queryFirstPage/{databaseId}/{collectionId}")]
        public PagedResult QueryFirstPage(string databaseId, string collectionId)
        {
            var task = SqlApiDocumentsRepo.QueryWithPaging(this._config, databaseId, collectionId);
            task.Wait();

            return task.Result;
        }

        [HttpPost]
        [Route("api/sql/documents/queryNextPage/{databaseId}/{collectionId}")]
        public PagedResult QueryNextPage(string databaseId, string collectionId, [FromBody] object continuationToken)
        {
            var task = SqlApiDocumentsRepo.QueryWithPaging(this._config, databaseId, collectionId, continuationToken);
            task.Wait();

            return task.Result;
        }

        [HttpGet]
        [Route("api/sql/documents/replace/{databaseId}/{collectionId}")]
        public string ReplaceDocuments(string databaseId, string collectionId)
        {
            var task = SqlApiDocumentsRepo.ReplaceDocuments(this._config, databaseId, collectionId);
            task.Wait();

            return task.Result;
        }

        [HttpGet]
        [Route("api/sql/documents/delete/{databaseId}/{collectionId}")]
        public string DeleteDocuments(string databaseId, string collectionId)
        {
            var task = SqlApiDocumentsRepo.DeleteDocuments(this._config, databaseId, collectionId);
            task.Wait();

            return task.Result;
        }

        #endregion

        #region "Indexing"

        [HttpGet]
        [Route("api/sql/indexing/automatic")]
        public string AutomaticIndexing()
        {
            var task = SqlApiIndexingRepo.AutomaticIndexing(this._config);
            task.Wait();

            return task.Result;
        }

        [HttpGet]
        [Route("api/sql/indexing/manual")]
        public string ManualIndexing()
        {
            var task = SqlApiIndexingRepo.ManualIndexing(this._config);
            task.Wait();

            return task.Result;
        }

        [HttpGet]
        [Route("api/sql/indexing/path")]
        public string PathIndexing()
        {
            var task = SqlApiIndexingRepo.PathIndexing(this._config);
            task.Wait();

            return task.Result;
        }

        #endregion

        #region "Security"

        [HttpGet]
        [Route("api/sql/users")]
        public IEnumerable<object> GetUsers()
        {
            var response = SqlApiSecurityRepo.GetUsers(this._config);
            return response;
        }

        [HttpGet]
        [Route("api/sql/createUsers")]
        public string CreateUsers()
        {
            var task = SqlApiSecurityRepo.CreateUsers(this._config);
            task.Wait();

            return task.Result;
        }

        [HttpGet]
        [Route("api/sql/createPermissions")]
        public object CreatePermissions()
        {
            var task = SqlApiSecurityRepo.CreatePermissions(this._config);
            task.Wait();

            return task.Result;
        }

        [HttpGet]
        [Route("api/sql/permissions/{userId}")]
        public IEnumerable<object> GetPermissions(string userId)
        {
            var response = SqlApiSecurityRepo.GetPermissions(this._config, userId);
            return response;
        }

        [HttpGet]
        [Route("api/sql/testPermissions/{userId}")]
        public async Task<string> TestPermissions(string userId)
        {
            var response = await SqlApiSecurityRepo.TestPermissions(this._config, userId);
            return response;
        }

        [HttpGet]
        [Route("api/sql/deleteUsers")]
        public string DeleteUsers()
        {
            var task = SqlApiSecurityRepo.DeleteUsers(this._config);
            task.Wait();

            return task.Result;
        }

        #endregion

        #region "Stored Procedures"

        [HttpGet]
        [Route("api/sql/createSprocs")]
        public async Task<string> CreateStoredProcedures()
        {
            var response = await SqlApiServerRepo.CreateStoredProcedures(this._config);
            return response;
        }

        [HttpGet]
        [Route("api/sql/sprocs")]
        public IEnumerable<object> GetStoredProcedures()
        {
            var response = SqlApiServerRepo.GetStoredProcedures(this._config);
            return response;
        }

        [HttpGet]
        [Route("api/sql/executeSproc/{sprocId}")]
        public async Task<string> ExecuteStoredProcedures(string sprocId)
        {
            var response = await SqlApiServerRepo.ExecuteStoredProcedure(this._config, sprocId);
            return response;
        }

        [HttpGet]
        [Route("api/sql/deleteSprocs")]
        public async Task<string> DeleteStoredProcedures()
        {
            var response = await SqlApiServerRepo.DeleteStoredProcedures(this._config);
            return response;
        }

        #endregion

        #region "Triggers"

        [HttpGet]
        [Route("api/sql/createTriggers")]
        public async Task<string> CreateTriggers()
        {
            var response = await SqlApiServerRepo.CreateTriggers(this._config);
            return response;
        }

        [HttpGet]
        [Route("api/sql/triggers")]
        public IEnumerable<object> GetTriggers()
        {
            var response = SqlApiServerRepo.GetTriggers(this._config);
            return response;
        }

        [HttpGet]
        [Route("api/sql/executeTrigger/{triggerId}")]
        public async Task<string> ExecuteTrigger(string triggerId)
        {
            var response = await SqlApiServerRepo.ExecuteTrigger(this._config, triggerId);
            return response;
        }

        [HttpGet]
        [Route("api/sql/deleteTriggers")]
        public async Task<string> DeleteTriggers()
        {
            var response = await SqlApiServerRepo.DeleteTriggers(this._config);
            return response;
        }

        #endregion

        #region "User-Defined Functions"

        [HttpGet]
        [Route("api/sql/createUdfs")]
        public async Task<string> CreateUserDefinedFunctions()
        {
            var response = await SqlApiServerRepo.CreateUserDefinedFunctions(this._config);
            return response;
        }

        [HttpGet]
        [Route("api/sql/udfs")]
        public IEnumerable<object> GetUserDefinedFunctions()
        {
            var response = SqlApiServerRepo.GetUserDefinedFunctions(this._config);
            return response;
        }

        [HttpGet]
        [Route("api/sql/executeUdf/{udfId}")]
        public string ExecuteUserDefinedFunction(string udfId)
        {
            var response = SqlApiServerRepo.ExecuteUserDefinedFunction(this._config, udfId);
            return response;
        }

        [HttpGet]
        [Route("api/sql/deleteUdfs")]
        public async Task<string> DeleteUserDefinedFunctions()
        {
            var response = await SqlApiServerRepo.DeleteUserDefinedFunctions(this._config);
            return response;
        }

        #endregion

    }

    public class CreateDatabaseRequest
    {
        public string DatabaseId { get; set; }
    }

    public class CreateCollectionRequest
    {
        public string DatabaseId { get; set; }
        public string CollectionId { get; set; }
        public string PartitionKey { get; set; }
        public int Throughput { get; set; }
    }

}
