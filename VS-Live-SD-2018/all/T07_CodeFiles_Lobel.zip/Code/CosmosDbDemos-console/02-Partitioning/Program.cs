﻿namespace CrossPartitionQueries
{
	class Program
	{
		static void Main(string[] args)
		{
			CrossPartitionQueriesDemo.Run().Wait();
		}
	}
}
