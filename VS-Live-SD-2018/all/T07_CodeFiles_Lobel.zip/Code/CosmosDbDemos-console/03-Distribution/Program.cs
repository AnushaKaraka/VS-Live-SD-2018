﻿namespace GlobalDistribution
{
	class Program
	{
		static void Main(string[] args)
		{
			CreateFamiliesCollection.Run().Wait();
//			GlobalDistributionDemo.Run().Wait();
		}

	}
}
