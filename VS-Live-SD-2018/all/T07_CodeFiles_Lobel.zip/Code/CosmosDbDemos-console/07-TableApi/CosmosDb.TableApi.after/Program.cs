﻿namespace CosmosDb.TableApi
{
	class Program
	{
		static void Main(string[] args)
		{
			TableDemo.Run();
		}

	}
}
