---------------------------------------------------------------
-- T-SQL Functions
---------------------------------------------------------------


/*
  -------------------------------------------------------------
  Analytic Functions
  -------------------------------------------------------------

    FIRST_VALUE
    LAST_VALUE
    LAG
    LEAD
    PERCENT_RANK
    CUME_DIST
    PERCENTILE_DISC
    PERCENTILE_CONT
*/


USE MyDB
GO

-- FIRST_VALUE, LAST_VALUE, LAG, LEAD

DECLARE @Orders AS table(OrderDate date, ProductID int, Quantity int)
INSERT INTO @Orders VALUES
 ('2011-03-18', 142, 74),
 ('2011-04-11', 123, 95),
 ('2011-04-12', 101, 38),
 ('2011-05-30', 101, 28),
 ('2011-05-21', 130, 12),
 ('2011-07-25', 123, 57),
 ('2011-07-28', 101, 12)

SELECT
  OrderDate,
  ProductID,
  Quantity,
  LowestOn = FIRST_VALUE(OrderDate) OVER(PARTITION BY ProductID ORDER BY Quantity),
  HighestOn = LAST_VALUE(OrderDate) OVER(PARTITION BY ProductID ORDER BY Quantity
                          ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING),
  ProductPrevOn = LAG(OrderDate, 1) OVER(PARTITION BY ProductID ORDER BY OrderDate),
  ProductNextOn = LEAD(OrderDate, 1) OVER(PARTITION BY ProductID ORDER BY OrderDate)
 FROM @Orders 
 ORDER BY OrderDate


-- PERCENT_RANK, CUME_DIST, PERCENTILE_DISC, PERCENTILE_CONT

DECLARE @Sales table(Yr int, Qtr int, Amount money)
INSERT INTO @Sales VALUES
  (2010, 1, 5000), (2010, 2, 6000), (2010, 3, 7000), (2010, 4, 2000),
  (2011, 1, 1000), (2011, 2, 2000), (2011, 3, 3000), (2011, 4, 4000)

-- Distributed across all 8 quarters
SELECT
  Yr, Qtr, Amount,
  R = RANK() OVER(ORDER BY Amount),
  PR = PERCENT_RANK() OVER(ORDER BY Amount),
  CD = CUME_DIST() OVER(ORDER BY Amount)
 FROM @Sales
 ORDER BY Amount

-- Distributed (partitioned) by year with percentile lookups
SELECT
  Yr, Qtr, Amount,
  R = RANK() OVER(PARTITION BY Yr ORDER BY Amount),
  PR = PERCENT_RANK() OVER(PARTITION BY Yr ORDER BY Amount),
  CD = CUME_DIST() OVER(PARTITION BY Yr ORDER BY Amount),
  PD5= PERCENTILE_DISC(.5) WITHIN GROUP (ORDER BY Amount) OVER(PARTITION BY Yr),
  PD6= PERCENTILE_DISC(.6) WITHIN GROUP (ORDER BY Amount) OVER(PARTITION BY Yr),
  PC5= PERCENTILE_CONT(.5) WITHIN GROUP (ORDER BY Amount) OVER(PARTITION BY Yr),
  PC6= PERCENTILE_CONT(.6) WITHIN GROUP (ORDER BY Amount) OVER(PARTITION BY Yr)
 FROM @Sales
 ORDER BY Yr, Amount


/*
  -------------------------------------------------------------
  Conversion Functions
  -------------------------------------------------------------

    PARSE
    TRY_CONVERT
    TRY_PARSE
*/

-- TRY_CONVERT
SELECT TRY_CONVERT(money, 'test') AS BadResult
SELECT TRY_CONVERT(money, '29.5') AS GoodResult

-- PARSE
SELECT PARSE('Monday, 13 December 2010' AS datetime2 USING 'en-US') AS USResult
SELECT PARSE('�345,98' AS money USING 'nl-NL') AS NLResult
SELECT PARSE('$345,98' AS money USING 'nl-NL') AS NLResult  -- Error, can't parse

-- TRY_PARSE
SELECT TRY_PARSE('$345,98' AS money USING 'nl-NL') AS NLResult  -- NULL, can't parse


/*
  -------------------------------------------------------------
  Date/Time Functions
  -------------------------------------------------------------

    DATEFROMPARTS
    TIMEFROMPARTS
    DATETIME2FROMPARTS
    DATETIMEOFFSETFROMPARTS
    SMALLDATETIMEFROMPARTS
    DATETIMEFROMPARTS
    EOMONTH
*/

-- xxxFROMPARTS
SELECT DATEFROMPARTS(2010, 12, 31) AS ADate
SELECT TIMEFROMPARTS (23, 59, 59, 1234567, 7) AS ATime
SELECT DATETIME2FROMPARTS (2010, 12, 31, 23, 59, 59, 1234567, 7) AS ADateTime2
SELECT DATETIMEOFFSETFROMPARTS (2010, 12, 31, 14, 23, 36, 5, 12, 0, 1) ADateTimeOff
SELECT DATETIMEFROMPARTS (2010, 12, 31, 23, 59, 59, 123) AS ADateTime
SELECT SMALLDATETIMEFROMPARTS (2010, 12, 31, 23, 59) AS ASmallDateTime

-- EOMONTH
SELECT EOMONTH('1/1/2011') AS LastDayOfMonth UNION ALL  -- 31
SELECT EOMONTH('2/1/2011') UNION ALL  -- 28
SELECT EOMONTH('3/1/2011') UNION ALL  -- 31
SELECT EOMONTH('4/1/2011') UNION ALL  -- 30
SELECT EOMONTH('2/1/2012')            -- 29 (leap year)

SELECT DATEPART(day, EOMONTH('2/1/2012')) AS DaysInFeb2012


/*
  -------------------------------------------------------------
  Logical Functions
  -------------------------------------------------------------

    CHOOSE
    IIF
*/

-- CHOOSE
DECLARE @CardTypeId int = 2  -- Master card
DECLARE @MC varchar(max) = 'MC'
SELECT CHOOSE(@CardTypeId, 'Amex', @MC, 'Visa', 'Discover') AS CardType

-- IIF (shorthand CASE statement)
DECLARE @Num1 int = 45
DECLARE @Num2 int = 40
SELECT IIF(@Num1 > @Num2, 'larger', 'not larger' ) AS Result


/*
  -------------------------------------------------------------
  String Functions
  -------------------------------------------------------------

    CONCAT
    FORMAT
*/

-- CONCAT (treats NULL as empty)
SELECT CONCAT('Happy', ' Birthday ', 8, '/', NULL, '30') AS Greeting

-- FORMAT (.NET string formatting)
DECLARE @Cultures table(Culture varchar(10), Lang varchar(50))
INSERT INTO @Cultures VALUES
 ('en', 'English'),
 ('nl', 'Dutch'),
 ('ja', 'Japanese'),
 ('ru', 'Russian'),
 ('no', 'Norwegian')

DECLARE @d datetime2 = DATETIME2FROMPARTS(2011, 2, 1, 16, 5, 0, 0, 7)
DECLARE @m money = 199.99

SELECT
  Lang,
  Date     = FORMAT(@d, 'd', Culture),
  TimeOnly = FORMAT(@d, 't', Culture),
  LongDate = FORMAT(@d, 'D', Culture),
  LongTime = FORMAT(@d, 'T', Culture),
  Dow      = FORMAT(@d, 'ddd', Culture),
  Currency = FORMAT(@m, 'c2', Culture)
 FROM
  @Cultures

-- Careful! Only hard-code individual date & time parts when targeting known cultures!
DECLARE @d datetime2 = DATETIME2FROMPARTS(2011, 2, 1, 16, 5, 0, 0, 7)
SELECT FORMAT(@d, 'ddd M/d/yyyy h:mm tt') AS DateAndTime

-- Alternative?
DECLARE @old_lang VARCHAR(32) = @@LANGUAGE
DECLARE @new_lang VARCHAR(32) = 'Dutch'
 
SET LANGUAGE @new_lang
SELECT DATENAME(WEEKDAY, SYSDATETIME())
SET LANGUAGE @old_lang


/*
  -------------------------------------------------------------
  Math Functions
  -------------------------------------------------------------

    LOG (changed)
*/

-- Can set the base of the logarithm to override the natural logarithm
SELECT CONCAT('The natural logarithm of 11 is: ', LOG(11)) AS Result
SELECT CONCAT('The base 10 logarithm of 11 is: ', LOG10(11)) AS Result

SELECT LOG(11) / LOG(2) AS Base2LogOf11
SELECT LOG(11, 2) AS Base2LogOf11
GO
