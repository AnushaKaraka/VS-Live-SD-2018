---------------------------------------------------------------
-- THROW (SQL Server 2012)
---------------------------------------------------------------

USE MyDB
GO

-- THROW can be used inside a CATCH block to re-throw the same error
CREATE TABLE ErrorLog(OccurredAt datetime2, Severity varchar(max), ErrMsg varchar(max));
BEGIN TRY 
  DECLARE @Number int = 5 / 0;
END TRY 
BEGIN CATCH 
  -- Log the error info, then re-throw it 
  INSERT INTO ErrorLog VALUES(SYSDATETIME(), ERROR_SEVERITY(), ERROR_MESSAGE()); 
  THROW;
END CATCH 

SELECT * FROM ErrorLog;


-- Both can be used to throw user errors (message 50000) at severity 16 ("red") with an adhoc message description
THROW 50000, 'An error occurred querying the table.', 1;
RAISERROR ('An error occurred querying the table.', 16, 1);

-- RAISERROR supports token substitutions; THROW does not
RAISERROR ('An error occurred querying the %s table.', 16, 1, 'Customer');

-- RAISERROR lets you set the severity; THROW severity is always 16 (unless re-throwing inside CATCH block)
RAISERROR ('A warning occurred querying the table.', 10, 1);   -- 10 and lower, "black"
RAISERROR ('An error occurred querying the table.', 11, 1);   -- 11 and higher, "red"

-- RAISERROR allows you to throw user messages with codes greater than 50000, but requires you to define
-- the message text in sys.messages. THROW does not require and never refers to sys.messages.
RAISERROR(66666, 16, 1, 'cat', 'morris');
EXEC sys.sp_addmessage 66666, 16, 'There is already a %s named %s.';
RAISERROR(66666, 16, 1, 'cat', 'morris');
THROW 66666, 'There is already a cat named morris', 1

-- FORMATMESSAGE workaround for THROW to utilize sys.messages for user errors (> 50000)
DECLARE @Message varchar(max) = FORMATMESSAGE(66666, 'dog', 'snoopy');
THROW 66666, @Message, 1;

-- RAISERROR can raise a system error; THROW cannot
RAISERROR(14088, 16, 1, N'foo');
THROW 14088, N'System error', 1;      -- error, must be 50000 or higher


-- Cleanup
EXEC sys.sp_dropmessage 66666;
DROP TABLE ErrorLog;
