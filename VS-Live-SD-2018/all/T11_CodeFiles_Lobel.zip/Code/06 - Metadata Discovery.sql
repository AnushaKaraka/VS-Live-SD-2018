---------------------------------------------------------------
-- Metadata discovery (SQL Server 2012)
---------------------------------------------------------------

USE AdventureWorks2012
GO

-- SET FMTONLY ON/OFF is deprecated
SET FMTONLY ON
SELECT * FROM HumanResources.Employee;
SET FMTONLY OFF
GO

-- Use new system stored procedures and data management functions (TVFs)
--  sys.sp_describe_first_result_set
--  sys.sp_describe_undeclared_parameters
--  sys.dm_exec_describe_first_result_set
--  sys.dm_exec_describe_first_result_set_for_object

-- Get the schema of the Employee table
EXEC sys.sp_describe_first_result_set
 @tsql = N'SELECT * FROM HumanResources.Employee'

-- TVF returns same information, but is queryable and you can limit metadata columns
SELECT name, system_type_name 
 FROM sys.dm_exec_describe_first_result_set(
  'SELECT * FROM HumanResources.Employee', NULL, 1)
 WHERE is_nullable = 1

-- Supports parameterized statements
SELECT name, system_type_name, is_hidden
 FROM sys.dm_exec_describe_first_result_set('
  SELECT OrderDate, TotalDue
   FROM Sales.SalesOrderHeader
   WHERE SalesOrderID = @OrderID',
  '@OrderID int', 1)

-- Multiple resultsets are no problem if they all have the same schema
SELECT name, system_type_name
 FROM sys.dm_exec_describe_first_result_set('
    IF @SortOrder = 1
      SELECT OrderDate, TotalDue
       FROM Sales.SalesOrderHeader
       ORDER BY SalesOrderID ASC
    ELSE IF @SortOrder = -1
      SELECT OrderDate, TotalDue
       FROM Sales.SalesOrderHeader
       ORDER BY SalesOrderID DESC',
   '@SortOrder AS tinyint', 0)

-- Stored proc throws exception if multiple resultsets have different columns
EXEC sys.sp_describe_first_result_set
  @tsql = N'
    IF @IncludeCurrencyRate = 1
      SELECT OrderDate, TotalDue, CurrencyRateID
       FROM Sales.SalesOrderHeader
    ELSE
      SELECT OrderDate, TotalDue
       FROM Sales.SalesOrderHeader'

--  The TVF will just return null data if multiple resultsets have different columns
SELECT name, system_type_name, is_hidden
 FROM sys.dm_exec_describe_first_result_set('
    IF @IncludeCurrencyRate = 1
      SELECT OrderDate, TotalDue, CurrencyRateID
       FROM Sales.SalesOrderHeader
    ELSE
      SELECT OrderDate, TotalDue
       FROM Sales.SalesOrderHeader',
   '@IncludeCurrencyRate AS bit', 0)

--  Non-identical schemas may still work instead of throwing an error,
--  if the number of columns and their data types match up. For example:
--   * if a column is NULLable in one schema but not NULLable in the other, the column will show as allowing NULLs
--   * if the column names are different, the column name will be returned as NULL

-- Use sys.dm_exec_describe_first_result_set_for_object to get the schema returned by a stored procedure (or trigger)
IF OBJECT_ID('GetOrderInfo', 'P') IS NOT NULL
 DROP PROCEDURE GetOrderInfo
GO

CREATE PROCEDURE GetOrderInfo(@OrderID AS int) AS
  SELECT OrderDate, TotalDue
   FROM Sales.SalesOrderHeader
   WHERE SalesOrderID = @OrderID
GO

SELECT name, system_type_name, is_hidden
 FROM sys.dm_exec_describe_first_result_set_for_object(OBJECT_ID('GetOrderInfo'), 1)

DROP PROCEDURE GetOrderInfo

-- Deduce undeclared parameters
EXEC sys.sp_describe_undeclared_parameters
 N'IF @IsFlag = 1 SELECT 1 ELSE SELECT 0'

