﻿var scrumChores = scrumChores || {};
scrumChores.models = scrumChores.models || {};