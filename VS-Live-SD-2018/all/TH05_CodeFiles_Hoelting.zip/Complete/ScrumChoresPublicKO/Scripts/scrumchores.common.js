//# sourceMappingURL=DateHelper.js.map
/// <reference path="../../../typings/knockout/knockout.d.ts" />
var scrumChores;
(function (scrumChores) {
    var models;
    (function (models) {
        var sprint = (function () {
            function sprint(SprintID, SprintName, SprintStartDate, SprintEndDate) {
                this.SprintID = ko.observable(SprintID);
                this.SprintName = ko.observable(SprintName);
                this.SprintStartDate = ko.observable(SprintStartDate);
                this.SprintEndDate = ko.observable(SprintEndDate);
                var self = this;
                this.SprintDateRange = ko.computed(function () {
                    return self.SprintStartDate() + ' - ' + self.SprintEndDate();
                });
            }
            return sprint;
        })();
        models.sprint = sprint;
    })(models = scrumChores.models || (scrumChores.models = {}));
})(scrumChores || (scrumChores = {}));
//# sourceMappingURL=Sprint.js.map
/// <reference path="../../../typings/knockout/knockout.d.ts" />
var scrumChores;
(function (scrumChores) {
    var models;
    (function (models) {
        var story = (function () {
            function story(Sprint, StoryID, Title, Description, Effort) {
                this.Sprint = ko.observable(Sprint);
                this.StoryID = ko.observable(StoryID);
                this.Title = ko.observable(Title);
                this.Description = ko.observable(Description);
                this.Effort = ko.observable(Effort);
            }
            return story;
        })();
        models.story = story;
    })(models = scrumChores.models || (scrumChores.models = {}));
})(scrumChores || (scrumChores = {}));
//# sourceMappingURL=Story.js.map