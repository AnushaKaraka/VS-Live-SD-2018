﻿
var gulp = require('gulp'),
bower = require('gulp-bower'),
rimraf = require("rimraf"),
concat = require("gulp-concat"),
cssmin = require("gulp-cssmin"),
runSequence = require('run-sequence'),
browsersync = require('browser-sync'),
uglify = require("gulp-uglify");

gulp.task('bower', function () {
    return bower({ layout: "byComponent" });
});

var paths = {
};

paths.koJsDebug = "scripts/knockout/dist/knockout.debug.js";
paths.koJs = "scripts/knockout/dist/knockout.js";
paths.koJsDest = "scripts/ko.js";

gulp.task("clean:koJs", function (cb) {
    rimraf(paths.koJsDest, cb);
});

gulp.task("copy:koJs", function (cb) {
    gulp.src([paths.koJsDebug])
      .pipe(concat(paths.koJsDest))
      .pipe(gulp.dest("."));
});

gulp.task("min:koJs", function () {
    gulp.src([paths.koJs])
      .pipe(concat(paths.koJsDest))
      .pipe(gulp.dest("."));
});

paths.scCommonJs = "scripts/scrumchorests/common/**/*.js";
paths.scCommonJsDest = "scripts/scrumchores.common.js";

gulp.task("clean:scCommonJs", function (cb) {
    rimraf(paths.scCommonJsDest, cb);
});

gulp.task("copy:scCommonJs", function (cb) {
    gulp.src([paths.scCommonJs], {
        base: "."
    })
      .pipe(concat(paths.scCommonJsDest))
      .pipe(gulp.dest("."));
});

gulp.task("min:scCommonJs", function () {
    gulp.src([paths.scCommonJs], {
        base: "."
    })
      .pipe(concat(paths.scCommonJsDest))
      .pipe(uglify())
      .pipe(gulp.dest("."));
});

paths.scChoreListJs = "scripts/scrumchorests/ViewModels/ChoreListVM.js";
paths.scChoreListJsDest = "scripts/scrumchores.chorelist.js";

gulp.task("clean:scChoreListJs", function (cb) {
    rimraf(paths.scChoreListJsDest, cb);
});

gulp.task("copy:scChoreListJs", function (cb) {
    gulp.src([paths.scChoreListJs], {
        base: "."
    })
      .pipe(concat(paths.scChoreListJsDest))
      .pipe(gulp.dest("."));
});

gulp.task("min:scChoreListJs", function () {
    gulp.src([paths.scChoreListJs], {
        base: "."
    })
      .pipe(concat(paths.scChoreListJsDest))
      .pipe(uglify())
      .pipe(gulp.dest("."));
});


paths.css = "content/**/*.css";
paths.minCss = "content/**/*.min.css";
paths.concatCssDest = "content/sitecss.css";

gulp.task("clean:css", function (cb) {
    rimraf(paths.concatCssDest, cb);
});

gulp.task("copy:css", function () {
    gulp.src([paths.css, "!" + paths.minCss])
      .pipe(concat(paths.concatCssDest))
      .pipe(gulp.dest("."));
});

gulp.task("min:css", function () {
    gulp.src([paths.css, "!" + paths.minCss])
      .pipe(concat(paths.concatCssDest))
      .pipe(cssmin())
      .pipe(gulp.dest("."));
});


gulp.task("clean", ["clean:koJs", "clean:scCommonJs", "clean:scChoreListJs", "clean:css"]);

gulp.task("copy", ["copy:koJs", "copy:scCommonJs", "copy:scChoreListJs", "copy:css"]);

gulp.task("min", ["min:koJs", "min:scCommonJs", "min:scChoreListJs", "min:css"]);

gulp.task('debug', function () {
    runSequence('bower', 'clean', 'copy');
});

gulp.task('release', function () {
    runSequence('bower', 'clean', 'min');
});

gulp.task('watch', function () {

    browsersync.init({
        proxy: "localhost/ScrumChoresPublicKO"
    });

    // Watch files
    gulp.watch('**/*.*', function (event) {
        gulp.run('debug');
        browsersync.reload();
    });
});