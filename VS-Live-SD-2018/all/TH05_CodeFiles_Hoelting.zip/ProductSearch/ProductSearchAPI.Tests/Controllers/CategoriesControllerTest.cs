﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Web.Http;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ProductSearchAPI;
using ProductSearchAPI.Controllers;
using ProductSearchCommon.POCOs;

namespace ProductSearchAPI.Tests.Controllers
{
    [TestClass]
    public class CategoriesControllerTest
    {
        [TestMethod]
        public void Get()
        {
            // Arrange
            CategoriesController controller = new CategoriesController();

            // Act
            IEnumerable<Category> result = controller.Get();

            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Any());
        }
    }
}
