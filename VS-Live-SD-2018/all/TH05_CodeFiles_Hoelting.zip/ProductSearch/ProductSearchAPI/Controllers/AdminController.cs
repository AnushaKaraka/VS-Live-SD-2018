﻿using ProductSearchCommon.POCOs;
using ProductSearchCommon.Queries;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using ProductSearchCommon;

namespace ProductSearchAPI.Controllers
{
    public class AdminController : ApiController
    {
        // GET api/admin
        public string Get(string command)
        {
            if (command == "ResetIndexes")
            {
                Constants.CategoriesAreIndexed = false;
                Constants.SubCategoriesAreIndexed = false;
                Constants.ModelsAreIndexed = false;
                Constants.ProductsAreIndexed = false;
                return "Indexes where reset.";
            }
            else
                return "No command sent";
        }

    }
}
