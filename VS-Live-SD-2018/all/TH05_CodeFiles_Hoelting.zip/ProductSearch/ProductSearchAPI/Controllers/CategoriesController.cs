﻿using ProductSearchCommon.POCOs;
using ProductSearchCommon.Queries;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using ProductSearchAPI.Helpers;

namespace ProductSearchAPI.Controllers
{
    public class CategoriesController : ApiController
    {
        // GET api/categories
        public IQueryable<Category> Get()
        {
            return ProductQueries.FillCategories(WebConstants.IndexFolder);
        }
    }
}
