﻿using ProductSearchCommon.POCOs;
using ProductSearchCommon.Queries;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ProductSearchAPI.Controllers
{
    public class ModelsController : ApiController
    {
        // GET api/models
        public IQueryable<Model> Get()
        {
            return ProductQueries.FillModels();
        }
        
    }
}
