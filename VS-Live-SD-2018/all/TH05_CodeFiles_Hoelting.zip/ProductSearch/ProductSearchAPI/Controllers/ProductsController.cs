﻿using ProductSearchCommon.POCOs;
using ProductSearchCommon.Queries;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace ProductSearchAPI.Controllers
{
    public class ProductsController : ApiController
    {
        // GET api/products
        public IQueryable<Product> Get()
        {
             return ProductQueries.FillProducts().AsQueryable();
        }

        // GET api/products/lucene/{query}
        [Route("api/products/name/{value}")]
        public IQueryable<Product> GetUsingLuceneQueryName(string value)
        {
            return ProductQueries.FillProductsUsingLuceneQueryName(value).AsQueryable();
        }

        // GET api/products/lucene/{query}
        [Route("api/products/desc/{value}")]
        public IQueryable<Product> GetUsingLuceneQueryDesc(string value)
        {
            return ProductQueries.FillProductsUsingLuceneQueryDesc(value).AsQueryable();
        }

        // GET api/products/lucene/{query}
        [Route("api/products/nameordesc/{name}/{desc}")]
        public IQueryable<Product> GetUsingLuceneQueryNameOrDesc(string name, string desc)
        {
            return ProductQueries.FillProductsUsingLuceneQueryNameOrDesc(name, desc).AsQueryable();
        }


        // GET api/products/lucene/{query}
        [Route("api/products/nameanddesc/{name}/{desc}")]
        public IQueryable<Product> GetUsingLuceneQueryNameAndDesc(string name, string desc)
        {
            return ProductQueries.FillProductsUsingLuceneQueryNameAndDesc(name, desc).AsQueryable();
        }
    }
}
