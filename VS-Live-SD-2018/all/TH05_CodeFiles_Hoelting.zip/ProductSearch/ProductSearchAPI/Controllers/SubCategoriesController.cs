﻿using ProductSearchAPI.Helpers;
using ProductSearchCommon.POCOs;
using ProductSearchCommon.Queries;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace ProductSearchAPI.Controllers
{
    public class SubCategoriesController : ApiController
    {
        // GET api/subcategories
        public IQueryable<SubCategory> Get()
        {
             return ProductQueries.FillSubCategories(WebConstants.IndexFolder);
        }
    }
}
