﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProductSearchAPI.Helpers
{
    public class WebConstants
    {
        public static string IndexFolder
        {
            get
            {
                string APP_PATH = System.Web.HttpContext.Current.Request.ApplicationPath.ToLower();
                if (APP_PATH == "/")      //a site
                    APP_PATH = "/";
                else if (!APP_PATH.EndsWith(@"/")) //a virtual
                    APP_PATH += @"/";

                string it = System.Web.HttpContext.Current.Server.MapPath(APP_PATH);
                if (!it.EndsWith(@"\"))
                    it += @"\";

                return it += @"App_Data\indexes\";
            }
        }
    }
}