export default {
  debug: true,
  testing: false
};
