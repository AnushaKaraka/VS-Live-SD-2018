export class App {
    configureRouter(config, router){
    config.title = 'Products';
    config.map([
      { route: '', moduleId: 'no-selection', title: 'Select'},
      { route: 'products/:id', moduleId: 'product-detail', name:'products' }
    ]);

    this.router = router;
  }
}
