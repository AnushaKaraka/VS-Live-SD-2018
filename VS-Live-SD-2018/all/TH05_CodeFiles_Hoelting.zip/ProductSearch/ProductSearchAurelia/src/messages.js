export class ProductUpdated {
  constructor(product) {
    this.product = product;
  }
}

export class ProductViewed {
  constructor(product) {
    this.product = product;
  }
}