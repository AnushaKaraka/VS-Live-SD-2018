export class NoSelection {
  constructor() {
    this.message = "Please Select a Product.";
  }
}