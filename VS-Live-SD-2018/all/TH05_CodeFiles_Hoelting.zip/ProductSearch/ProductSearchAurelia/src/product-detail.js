import {EventAggregator} from 'aurelia-event-aggregator';
import {WebAPI} from './web-api';
import {ProductUpdated,ProductViewed} from './messages';
import {areEqual} from './utility';

export class ProductDetail {
  static inject = [WebAPI, EventAggregator];

  constructor(api, ea){
    this.api = api;
    this.ea = ea;
  }

  activate(params, routeConfig) {
    this.routeConfig = routeConfig;

    return this.api.getProductDetails(params.id).then(product => {
      this.product = product;
      this.routeConfig.navModel.setTitle(product.firstName);
      this.originalProduct = JSON.parse(JSON.stringify(product));
      this.ea.publish(new ProductViewed(this.product));
    });
  }

  get canSave() {
    return this.product.firstName && this.product.lastName && !this.api.isRequesting;
  }

  save() {
    this.api.saveProduct(this.product).then(product => {
      this.product = product;
      this.routeConfig.navModel.setTitle(product.firstName);
      this.originalProduct = JSON.parse(JSON.stringify(product));
    });
  }

  canDeactivate() {
     if(!areEqual(this.originalProduct, this.product)){
      let result = confirm('You have unsaved changes. Are you sure you wish to leave?');

      if(!result) {
        this.ea.publish(new ProductViewed(this.product));
      }

      return result;
    }

    return true;
  }
}