import {EventAggregator} from 'aurelia-event-aggregator';
import {WebAPI} from './web-api';
import {ProductUpdated, ProductViewed} from './messages';

export class ProductList {
  static inject = [WebAPI, EventAggregator];

  constructor(api, ea) {
    this.api = api;
    this.products = [];

    ea.subscribe(ProductViewed, msg => this.select(msg.product));
    ea.subscribe(ProductUpdated, msg => {
      let id = msg.product.id;
      let found = this.products.find(x => x.id === id);
      Object.assign(found, msg.product);
    });
  }

  created() {
    this.api.getProductList().then(products => this.products = products);
  }

  select(product) {
    this.selectedId = product.id;
    return true;
  }
}