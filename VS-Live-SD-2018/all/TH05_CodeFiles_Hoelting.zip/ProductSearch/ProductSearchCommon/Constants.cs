﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductSearchCommon
{
    public static class Constants
    {
        public static string IndexPath = "";

        public static bool CategoriesAreIndexed = false;

        public static bool SubCategoriesAreIndexed = false;

        public static bool ModelsAreIndexed = false;

        public static bool ProductsAreIndexed = false;

        public static string ConnectionString = "Server=tcp:d0sxr7q27r.database.windows.net,1433;Database=AdventureWorks2012;User ID=bhoelting@d0sxr7q27r;Password=Luthien16Dr16zzt;Trusted_Connection=False;Encrypt=True;Connection Timeout=30";

        public static string ModelTableName = "Production.ProductModel";

        public static string ModelFields = "ProductModelID, Name";

        public static string CategoryTableName = "Production.ProductCategory";

        public static string CategoryFields = "ProductCategoryID, Name";

        public static string SubCategoryJoin = "Production.ProductSubCategory as SubCat " +
                                                "inner join Production.ProductCategory as Cat " +
                                                "on SubCat.ProductCategoryID = Cat.ProductCategoryID";

        public static string SubCategoryFields = "SubCat.ProductSubcategoryID, " +
                                                "SubCat.Name, SubCat.ProductCategoryID, " +
                                                "Cat.ProductCategoryID, Cat.Name";

        public static string ProductJoin = "Production.Product as Prod inner join "+
                                            "Production.ProductModel as Model " +
                                            "on Prod.ProductModelID = Model.ProductModelID " +
                                            "inner join Production.ProductModelProductDescriptionCulture as pmx " +
                                            "on Model.ProductModelID = pmx.ProductModelID " +
                                            "inner join Production.ProductDescription as pd " +
                                            "on pmx.ProductDescriptionID = pd.ProductDescriptionID " +
                                            "inner join Production.ProductSubCategory as SubCat " +
                                            "on Prod.ProductSubcategoryID = SubCat.ProductSubcategoryID " +
                                            "inner join Production.ProductCategory as Cat " +
                                            "on SubCat.ProductCategoryID = Cat.ProductCategoryID " +
                                            "where pmx.CultureID = 'en'";

        public static string ProductFields = "Prod.ProductID, " +
                                            "Prod.ProductNumber, Prod.Name, pd.Description, " +
                                            "Prod.Color, Prod.Size, " +
                                            "Prod.Weight, Prod.ListPrice, " +
                                            "Prod.ProductSubcategoryID, Prod.ProductModelID, " +
                                            "Model.ProductModelID, " +
                                            "Model.Name, " +
                                            "SubCat.ProductSubcategoryID, " +
                                            "SubCat.Name, SubCat.ProductCategoryID, " + 
                                            "Cat.ProductCategoryID, Cat.Name";
    }
}
