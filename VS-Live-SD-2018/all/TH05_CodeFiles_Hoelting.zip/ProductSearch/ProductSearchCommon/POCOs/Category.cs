﻿using System;
using Lucene.Net.Analysis.Standard;
using Lucene.Net.Linq;
using Lucene.Net.Linq.Mapping;
using Lucene.Net.Store;

namespace ProductSearchCommon.POCOs
{
    public class Category
    {
        [NumericField]
        public int ProductCategoryID { get; set; }

        [Field(Analyzer = typeof(StandardAnalyzer))]
        public string Name { get; set; }
    }
}
