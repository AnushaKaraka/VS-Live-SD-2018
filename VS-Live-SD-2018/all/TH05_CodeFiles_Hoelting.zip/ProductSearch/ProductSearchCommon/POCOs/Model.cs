﻿using Lucene.Net.Analysis.Standard;
using Lucene.Net.Linq;
using Lucene.Net.Linq.Mapping;
using Lucene.Net.Store;

namespace ProductSearchCommon.POCOs
{
    public class Model
    {
        [NumericField]
        public int ProductModelID { get; set; }

        [Field(Analyzer = typeof(StandardAnalyzer))]
        public string Name { get; set; }
    }
}
