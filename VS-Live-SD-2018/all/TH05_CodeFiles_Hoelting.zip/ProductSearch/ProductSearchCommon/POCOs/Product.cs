﻿using Lucene.Net.Analysis.Standard;
using Lucene.Net.Linq;
using Lucene.Net.Linq.Mapping;
using Lucene.Net.Store;

namespace ProductSearchCommon.POCOs
{
    public class Product
    {
        [NumericField]
        public int ProductId { get; set; }

        [Field(Analyzer = typeof(StandardAnalyzer))]
        public string ProductNumber { get; set; }

        [Field(Analyzer = typeof(StandardAnalyzer))]
        public string Name { get; set; }

        [Field(Analyzer = typeof(StandardAnalyzer))]
        public string Description { get; set; }

        [Field(Analyzer = typeof(StandardAnalyzer))]
        public string Color { get; set; }

        [Field(Analyzer = typeof(StandardAnalyzer))]
        public string Size { get; set; }

        [Field(Analyzer = typeof(StandardAnalyzer))]
        public string Weight { get; set; }

        [Field(Analyzer = typeof(StandardAnalyzer))]
        public decimal ListPrice { get; set; }

        [NumericField]
        public int ProductSubcategoryID { get; set; }

        [Field(Converter = typeof(JSONConverter<SubCategory>))]
        public SubCategory SubCategory { get; set; }

        [NumericField]
        public int ProductModelID { get; set; }

        [Field(Converter = typeof(JSONConverter<Model>))]
        public Model Model { get; set; }
    }
}
