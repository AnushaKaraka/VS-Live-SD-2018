﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lucene.Net.Linq;
using Lucene.Net.Store;

namespace ProductSearchCommon.Queries
{
    public class LuceneSessionFactory
    {
        private static RAMDirectory _directory = new RAMDirectory();
        private static LuceneDataProvider _modelProvider;
        private static LuceneDataProvider _categoryProvider;
        private static LuceneDataProvider _subCategoryProvider;
        private static LuceneDataProvider _productProvider;

        public static LuceneDataProvider Instance(string sessionType)
        {
            switch (sessionType)
            {
                case "ProductSearchCommon.POCOs.Model":
                    return _modelProvider ?? (_modelProvider = new LuceneDataProvider(_directory, Lucene.Net.Util.Version.LUCENE_30));
                case "ProductSearchCommon.POCOs.Category":
                    return _categoryProvider ?? (_categoryProvider = new LuceneDataProvider(_directory, Lucene.Net.Util.Version.LUCENE_30));
                case "ProductSearchCommon.POCOs.SubCategory":
                    return _subCategoryProvider ?? (_subCategoryProvider = new LuceneDataProvider(_directory, Lucene.Net.Util.Version.LUCENE_30));
                case "ProductSearchCommon.POCOs.Product":
                    return _productProvider ?? (_productProvider = new LuceneDataProvider(_directory, Lucene.Net.Util.Version.LUCENE_30));
                default:
                    return null;
            }
        }
    }
}
