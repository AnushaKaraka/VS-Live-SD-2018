﻿using System;
using System.Linq;
using ProductSearchCommon.POCOs;
using Dapper;
using System.Data.SqlClient;
using Lucene.Net.Index;
using Lucene.Net.Store;
using Lucene.Net.Analysis.Standard;
using Lucene.Net.Documents;
using Lucene.Net.Linq;

namespace ProductSearchCommon.Queries
{
    public static class ProductQueries
    {
        public static IQueryable<Model> FillModels()
        {
            IQueryable<Model> models;

            if (!Constants.ModelsAreIndexed)
            {
                using (var sqlConnection =
                    new SqlConnection(Constants.ConnectionString))
                {
                    sqlConnection.Open();

                    models = sqlConnection.Query<Model>(string.Format("Select {0} from {1}",
                        Constants.ModelFields, Constants.ModelTableName)).AsQueryable();

                    sqlConnection.Close();
                }

                using (var session = LuceneSessionFactory.Instance(typeof(Model).ToString()).OpenSession<Model>())
                {
                    session.DeleteAll();

                    foreach (var model in models)
                    {
                        session.Add(model);
                    }
                }

                Constants.ModelsAreIndexed = true;
            }
            else
            {
                models = LuceneSessionFactory.Instance(typeof(Model).ToString()).AsQueryable<Model>();
            }

            return models;

        }


        public static IQueryable<Category> FillCategories(string indexPath)
        {
            IQueryable<Category> categories;

            if (!Constants.CategoriesAreIndexed)
            {
                using (var sqlConnection =
                    new SqlConnection(Constants.ConnectionString))
                {
                    sqlConnection.Open();

                    categories = sqlConnection.Query<Category>(string.Format("Select {0} from {1}",
                        Constants.CategoryFields, Constants.CategoryTableName)).AsQueryable();

                    sqlConnection.Close();
                }

                using (var session = LuceneSessionFactory.Instance(typeof(Category).ToString()).OpenSession<Category>())
                {
                    session.DeleteAll();

                    foreach (var category in categories)
                    {
                        session.Add(category);
                    }
                }

                Constants.CategoriesAreIndexed = true;
            }
            else
            {
                categories = LuceneSessionFactory.Instance(typeof(Category).ToString()).AsQueryable<Category>();
            }

            return categories;

        }

        public static IQueryable<SubCategory> FillSubCategories(string indexPath)
        {
            IQueryable<SubCategory> subCategories;

            if (!Constants.SubCategoriesAreIndexed)
            {
                using (var sqlConnection =
                    new SqlConnection(Constants.ConnectionString))
                {
                    sqlConnection.Open();


                    subCategories =
                        sqlConnection.Query<SubCategory, Category, SubCategory>(string.Format("Select {0} from {1}",
                            Constants.SubCategoryFields, Constants.SubCategoryJoin), (subCat, cat) =>
                            {
                                subCat.Category = cat;
                                return subCat;
                            },
                            splitOn: "ProductCategoryID"
                            ).AsQueryable();

                    sqlConnection.Close();
                }

                using (var session = LuceneSessionFactory.Instance(typeof(SubCategory).ToString()).OpenSession<SubCategory>())
                {
                    session.DeleteAll();

                    foreach (var subcategory in subCategories)
                    {
                        session.Add(subcategory);
                    }
                }

                Constants.SubCategoriesAreIndexed = true;
            }
            else
            {
                subCategories = LuceneSessionFactory.Instance(typeof(SubCategory).ToString()).AsQueryable<SubCategory>();
            }

            return subCategories;
        }


        public static IQueryable<Product> FillProducts()
        {
            IQueryable<Product> products;

            if (!Constants.ProductsAreIndexed)
            {
                products = FillProductsFromDB();
            }
            else
            {
                products = LuceneSessionFactory.Instance(typeof(Product).ToString()).AsQueryable<Product>();
            }

            return products;
        }

        public static IQueryable<Product> FillProductsUsingLuceneQueryName(string name)
        {
            IQueryable<Product> products;

            if (!Constants.ProductsAreIndexed)
            {
                products = FillProductsFromDB();
            }

            products = LuceneSessionFactory.Instance(typeof(Product).ToString()).OpenSession<Product>().Query().Where(x => x.Name.Contains(name));

            return products;
        }

        public static IQueryable<Product> FillProductsUsingLuceneQueryDesc(string desc)
        {
            IQueryable<Product> products;

            if (!Constants.ProductsAreIndexed)
            {
                products = FillProductsFromDB();
            }

            products = LuceneSessionFactory.Instance(typeof(Product).ToString()).OpenSession<Product>().Query().Where(x => x.Description.Contains(desc));

            return products;
        }

        public static IQueryable<Product> FillProductsUsingLuceneQueryNameOrDesc(string name, string desc)
        {
            IQueryable<Product> products;

            if (!Constants.ProductsAreIndexed)
            {
                products = FillProductsFromDB();
            }

            products = LuceneSessionFactory.Instance(typeof(Product).ToString()).OpenSession<Product>().Query().Where(x => x.Name.Contains(name).Boost(2.0f) || x.Description.Contains(desc));

            return products;
        }
        
        public static IQueryable<Product> FillProductsUsingLuceneQueryNameAndDesc(string name, string desc)
        {
            IQueryable<Product> products;

            if (!Constants.ProductsAreIndexed)
            {
                products = FillProductsFromDB();
            }

            products = LuceneSessionFactory.Instance(typeof(Product).ToString()).OpenSession<Product>().Query().Where(x => x.Name.Contains(name) && x.Description.Contains(desc));

            return products;
        }

        private static IQueryable<Product> FillProductsFromDB()
        {
            IQueryable<Product> products;
            using (var sqlConnection = new SqlConnection(Constants.ConnectionString))
            {
                sqlConnection.Open();


                products =
                    sqlConnection.Query<Product, Model, SubCategory, Category, Product>(
                        string.Format("Select {0} from {1}",
                            Constants.ProductFields, Constants.ProductJoin), (prod, model, subCat, cat) =>
                            {
                                prod.Model = model;
                                prod.SubCategory = subCat;
                                subCat.Category = cat;
                                return prod;
                            },
                        splitOn: "ProductModelID, ProductSubcategoryID, ProductCategoryID"
                        ).AsQueryable();

                sqlConnection.Close();
            }


            using (var session = LuceneSessionFactory.Instance(typeof(Product).ToString()).OpenSession<Product>())
            {
                session.DeleteAll();

                foreach (var product in products)
                {
                    session.Add(product);
                }

            }

            Constants.ProductsAreIndexed = true;
            return products;
        }

    }
}
